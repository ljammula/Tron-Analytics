# Tron

## Install Instructions
### Download Latest version of STS. Download latest version of Java. Import the project. Right click on TronApplication and select Run As -> SpringBoot Application