package com.tronanalytics.tron.web.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.tronanalytics.tron.dto.FeatureDto;
import com.tronanalytics.tron.dto.ModelDto;
import com.tronanalytics.tron.service.ModelService;

@Controller
@RequestMapping("/models")
public class ModelController {

	@Autowired
	private ModelService modelService;
	
	@GetMapping("")
    public String homePage(Model model) 
	{
		List<ModelDto> modelList = modelService.getModels();
		model.addAttribute("modelList", modelList);
		
        return "models/list";
    }
	
	@GetMapping("/new")
	public String showNewModelPage(Model model) {
		
		model.addAttribute("modelDto", new ModelDto());
		return "models/new";
	}
	
	@PostMapping("/new")
	public ModelAndView processNewModel(@ModelAttribute ModelDto modelDto) {
		
		// Initialize EDA
		String uuid = modelService.initEda(modelDto);

		// Save the model
		modelDto.setUuid(uuid);
		modelService.saveModel(modelDto);
		
		ModelMap model = new ModelMap();
		model.addAttribute("uuid", uuid);
		model.addAttribute("step", "eda");
		
	    return new ModelAndView("redirect:/models/processing", model);
	}
	
	@GetMapping("/processing")
	public String showModelProcessing(@RequestParam("uuid") String uuid, @RequestParam("step") String step, Model model) {
		
		model.addAttribute("uuid", uuid);
		model.addAttribute("step", step);
		
		return "models/processing";
	}
	
	
	@GetMapping("/processingstatus")
	@ResponseBody
	public String getProcessingStatus(@RequestParam("uuid") String uuid, @RequestParam("step") String step, Model model) {
		
		return modelService.getProcessingStatus(uuid, step);
	}
	
	
	@GetMapping("/eda")
	public String showEdaPage(@RequestParam("uuid") String uuid, Model model) {
		
		model.addAttribute("uuid", uuid);
		List<FeatureDto> features = modelService.getFeatures(uuid);
		
		model.addAttribute("features", features);
		return "models/eda";
	}
	
	@PostMapping("/eda")
	public ModelAndView processEda(@RequestParam("uuid") String uuid, @RequestParam(value = "feature[]")String[] features) {
		
		// Call the Python Code to initiate model creation
		modelService.initModel(uuid, features);
		
		ModelMap model = new ModelMap();
		model.addAttribute("uuid", uuid);
		model.addAttribute("step", "model");
		
		return new ModelAndView("redirect:/models/processing", model);
	}
	
	@GetMapping("/model")
	public String showModelPage(@RequestParam("uuid") String uuid, Model model) {
		
		model.addAttribute("uuid", uuid);
		
		return "models/model";
	}
	
	@PostMapping("/model")
	public ModelAndView saveModel() {
		
		ModelMap model = new ModelMap();
		
		return new ModelAndView("redirect:/models/", model);
	}
	
}
