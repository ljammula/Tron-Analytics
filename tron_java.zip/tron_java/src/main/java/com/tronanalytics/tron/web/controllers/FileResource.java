package com.tronanalytics.tron.web.controllers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class FileResource {


	@Value("${app.shared.folder}")
	private String sharedFolder;
	
	@GetMapping("/fileresource")
	@ResponseBody
	public String getFile(@RequestParam String uuid, @RequestParam String path) throws IOException {
	
		File file = new File(sharedFolder + "/" + uuid + "/" + path);
		
		return FileUtils.readFileToString(file);
	}
	
	@GetMapping("/download")
	@ResponseBody
	public void downloadFile(@RequestParam String uuid, @RequestParam String path, HttpServletResponse response) throws IOException {
	
		File file = new File(sharedFolder + "/" + uuid + "/" + path);
		
		response.setContentType("application/pmml");
		response.setHeader("Content-Disposition", "attachment; filename=" + uuid + ".pmml");
		
        Files.copy(file.toPath(), response.getOutputStream());
        response.getOutputStream().flush();
		
	}
	
}
