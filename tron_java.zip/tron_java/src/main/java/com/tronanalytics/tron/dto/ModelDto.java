package com.tronanalytics.tron.dto;

import org.springframework.web.multipart.MultipartFile;

public class ModelDto {

	private String modelName;
	private String type;
	private String algorithm;
	private String version;
	private MultipartFile dataFile;
	private String uuid;
	
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getType() { return type; }
	public void setType(String type) { this.type = type; }
	public String getAlgorithm() { return algorithm; }
	public void setAlgorithm(String algorithm) { this.algorithm = algorithm; }
	public MultipartFile getDataFile() { return dataFile; }
	public void setDataFile(MultipartFile dataFile) { this.dataFile = dataFile; }
	public String getVersion() { return version; }
	public void setVersion(String version) { this.version = version; }
	public String getUuid() { return uuid; }
	public void setUuid(String uuid) { this.uuid = uuid; }
	
	@Override
	public String toString() {
		return "ModelDto [name=" + modelName + ", type=" + type + ", algorithm=" + algorithm + ", dataFile Size=" + dataFile.getSize() + "]";
	}
	
}
