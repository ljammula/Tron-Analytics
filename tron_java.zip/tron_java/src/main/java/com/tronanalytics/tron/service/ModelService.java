package com.tronanalytics.tron.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.tronanalytics.tron.dto.FeatureDto;
import com.tronanalytics.tron.dto.ModelDto;

@Service
public class ModelService {
	
	private static Logger logger = LoggerFactory.getLogger(ModelService.class);
	
	@Value("${app.shared.folder}")
	private String sharedFolder;
	
	@Value("${tron.model.api.url}")
	private String tronModelApiUrl;
	
	
	public String initEda(ModelDto modelDto) {
		
		// Generate a UUID
		String uuid = "";
				
		try {
			uuid = UUID.randomUUID().toString();
			// Save the file under the share as data.csv
			File uuidDir = new File(sharedFolder + "/" + uuid);
			boolean uuidResult = uuidDir.mkdir();
			logger.info("Result of creating " + uuidDir.getAbsolutePath() + " " + uuidResult);
			
			// Create the input directory
			File inputDir = new File(uuidDir.getAbsolutePath() + "/input");
			boolean inputDirResult = inputDir.mkdir();
			
			// Need to check flags before creating the file
			File dataFile = new File(inputDir.getAbsoluteFile() + "/" + "data.csv");
			modelDto.getDataFile().transferTo(dataFile);
			
			// Trigger a call to the Python EDA Service
			String response = postToTronModelApi("generate_eda_async", uuid, "");
			System.out.println(response);
		}
		catch(Exception e) {
			logger.error("Error initiating EDA", e);
		}
		
		return uuid;
	}
	
	public void saveModel(ModelDto modelDto) {
		
		try {
			File modelDataFile = new File(sharedFolder + "/model-data.txt");
			if(!modelDataFile.exists()) {
				modelDataFile.createNewFile();
			}
			
			// Open the file
			List<String> data = FileUtils.readLines(modelDataFile, "UTF-8");
			// Create a new string based on new data
			String newData = modelDto.getModelName() + ";" + modelDto.getType() + ";" + modelDto.getAlgorithm() + ";" +
							 modelDto.getVersion() + ";" + modelDto.getUuid() + ";"; 
			
			data.add(newData);
			FileUtils.writeLines(modelDataFile, "UTF-8", data, false); 
		}
		catch(Exception e) {
			logger.error("Error saving model", e);
		}
	}

	public List<ModelDto> getModels() {
		
		List<ModelDto> models = new ArrayList<>();
		
		try {
			File modelDataFile = new File(sharedFolder + "/model-data.txt");
			if(!modelDataFile.exists()) {
				modelDataFile.createNewFile();
			}
			
			// Open the file
			List<String> fileDataLines = FileUtils.readLines(modelDataFile, "UTF-8");
			
			for(String line : fileDataLines) {
				String[] items = line.split(";");
				ModelDto modelDto = new ModelDto();
				modelDto.setModelName(items[0]);
				modelDto.setType(items[1]);
				modelDto.setAlgorithm(items[2]);
				modelDto.setVersion(items[3]);
				modelDto.setUuid(items[4]);
				
				models.add(modelDto);
			}
			
		}
		catch(Exception e) {
			logger.error("Error saving model", e);
		}
		
		return models;
	}
	
	public String initModel(String uuid, String[] features) {
		
		String json = createJsonRequest(features);
		String response = postToTronModelApi("train_model_async", uuid, json);
		return uuid;
	}
	
	private String createJsonRequest(String[] features) {
		String json = "";
		try {
			ObjectMapper mapper = new ObjectMapper();
			String featureJson = mapper.writeValueAsString(features);

			// quick fix to get this working
			json = "{ \"features\": " +  featureJson + " }";
		}
		catch(JsonProcessingException e) {
			logger.error("Error converting features into JSON ", e);
		}
		return json;
	}
	
	private String readFromJsonResponse(String jsonResponse) {
		String value = "";
		
		try {
			ObjectMapper mapper = new ObjectMapper();
			JsonNode root = mapper.readTree(jsonResponse);
			JsonNode status = root.path("status");
		}
		catch(IOException e) {
			logger.error("Error reading from JSON Response", e);
		}
		return value;
	}
	
	private String postToTronModelApi(String resource, String uuid, String body) {
		
		RestTemplate restTemplate = new RestTemplate();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		HttpEntity<String> request = new HttpEntity<>(body, headers);
		
		String url = tronModelApiUrl + resource + "?uuid=" + uuid;
		ResponseEntity<String> response = restTemplate.postForEntity(url, request , String.class);
		
		return response.getBody();
	}
	
	public String getProcessingStatus(String uuid, String step) {
		
		String status = "";
		
		if("eda".equalsIgnoreCase(step)) {
			status = getEdaProcessingStatus(uuid);
		}
		else if("model".equalsIgnoreCase(step)) {
			status = getModelProcessingStatus(uuid);
		}
		
		
		return status;
	}
	
	private String getEdaProcessingStatus(String uuid) {
		
		File edaFile = new File(sharedFolder + "/" + uuid + "/flags/eda.flg");
		
		
		return edaFile.exists() ? "EDA_COMPLETED" : "EDA_IN_PROCESS";
	}
	
	private String getModelProcessingStatus(String uuid) {
		
		File edaFile = new File(sharedFolder + "/" + uuid + "/flags/model.flg");
		
		
		return edaFile.exists() ? "MODEL_COMPLETED" : "MODEL_IN_PROCESS";
	}
	
	public List<FeatureDto> getFeatures(String uuid) {
		
		List<FeatureDto> features = new ArrayList<>();
		
		try {
			File featuresFile = new File(sharedFolder + "/" + uuid + "/eda/eda-info/features.txt");
			List<String> featureStr = FileUtils.readLines(featuresFile, "UTF-8");
		
			for(String f : featureStr) {
				FeatureDto featureDto = new FeatureDto();
				featureDto.setName(f);
				features.add(featureDto);
			}
			
		}
		catch(IOException e) {
			logger.error("Error reading features", e);
		}
		
		return features;
	}
	
	
}
