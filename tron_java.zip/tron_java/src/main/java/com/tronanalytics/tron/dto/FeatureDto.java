package com.tronanalytics.tron.dto;

public class FeatureDto {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
