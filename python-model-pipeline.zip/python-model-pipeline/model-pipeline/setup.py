import os
import sys
from shutil import copytree, rmtree

# TODO check dependecies and install them if possible or warn
print('**** NOTE: only supports python 3.7 ***')
# Find python install directory
prefix = sys.prefix

operating_system = input("enter 'W' for windows or 'M' for mac to continue:")
if operating_system == 'M':
    # path = os.path.join(prefix, 'lib', 'python3.6', 'site-packages')
    path = '/Users/laxminarsimhareddyjammula/opt/anaconda3/lib/python3.8/site-packages/' #change this depending on python local installation path
else:
    path = os.path.join(prefix, 'Lib', 'site-package')

install_dir = os.path.join(path, 'python_model_pipeline')

# warn user if directory already exists and needs to be removed
if os.path.isdir(install_dir):
    print('***')
    print("Running this file will remove the currently installed "
          "version of python_model_pipeline.\n"
          "Proceed only if you haven't made any changes "
          "to current version that you'd like to keep.")
    print('***')
    confirmation = input("type 'Y' to continue:")
    if confirmation == 'Y':
        print("Removing current python_model_pipeline folder.")
        rmtree(install_dir)
    else:
        print("Exiting setup, no changes will be made.")
        exit()

# copy to install directory
print('Copying files.')
copytree('src', install_dir)

# Add pth file so the package is recognized by python and can be imported
with open(os.path.join(path, "python_model_pipeline.pth"), 'w') as f:
    f.write("./python_model_pipeline")

# Finish
print("Setup complete. Package can now be accessed with 'import python_model_pipeline'")
