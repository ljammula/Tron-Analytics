from in_out.data_files import import_data_csv
from preprocessing import create_balanced_dataset,impute
import pandas as pd


def balance_df_test():
    print('\n\nTesting balance')
    # Import data to test with
    df = import_data_csv('../../src/data/train.csv')
    print('data imported')
    df_original = df
    cols = df.columns
    keep_cols = [cols[0], cols[1]]
    df = df[keep_cols]
    print(df.columns)
    target = cols[0]
    print(len(df[target]))
    predictors = cols[1]
    print(len(df[predictors]))
    create_balanced_dataset(pd.DataFrame(df[predictors]), df[target])
    print('*****************************************\n\n')


def impute_df_test():
    print('\n\nTesting balance')
    # Import data to test with
    df = import_data_csv('../../src/data/train.csv')
    print('data imported')
    df_original = df
    cols = df.columns
    impute(df, 'mean')
    numeric_cols = [x for x in cols if df[x].dtype != object]
    print('\n\n Nan before imputing are')
    for x in numeric_cols:
        print('nan in ', x, ' are :\n', pd.isnull(df[x]).sum())
    df = impute(df, 'mean')
    print('\n\n Nan after imputing are')
    for x in numeric_cols:
        print('nan in ', x, ' are :\n', pd.isnull(df[x]).sum())


impute_df_test()