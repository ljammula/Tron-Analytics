from in_out.data_files import import_data_csv
import preprocessing
import pandas as pd
import eda
import numpy as np
import os.path
from html_converter import generate_html_output_with_links


def test_encode_series_numeric_labels():
    # step-1 import data set & identify target
    df = import_data_csv('../../src/data/train.csv')
    print('data imported')
    df_original = df.copy()
    cols = df.columns
    print('columns in df are:\n', cols)
    target = df[cols[0]]
    # replace Null, NA with np.NAN
    df = df.replace('NULL', np.NAN)
    df = df.replace('NA', np.NAN)

    # Step-2: Do summary statistics part-1
    # go through the text file
    eda.dataset_stats_info(df)

    # step-3 delete columns which are not significant just by glancing (some examples are names, id's...)
    # remove name
    df = df.drop(['Name'], axis=1)
    cols = df.columns

    # Step-4: perform EDA
    # i) plot visualizations to understand data better
    eda.export_histograms(df, extension='.png')
    eda.export_boxplot(df, cols[0], None, 'All', '', '.png')
    eda.export_correlation_plot(df, '', '.png')
    # ii) generate a single html with visualizations
    imgs_dir = os.path.realpath(os.path.join(os.getcwd(), "../", "reports", "figures/"))
    output_dir = os.path.realpath(os.path.join(os.getcwd(), "../", "reports"))
    generate_html_output_with_links(imgs_dir, 'EDA', 'EDA_with_links.html', output_dir, 'eda')

    # step-5: remove columns which have too much missing data
    df = preprocessing.remove_features_missing_data(df)
    cols = df.columns

    # step-6: perform label encoding
    numeric_cols = [x for x in cols if df[x].dtype != object]
    print('\nnumeric columns are:\n', numeric_cols)
    non_numeric_cols = [x for x in cols if df[x].dtype == object]
    print('\nNon numeric columns are:\n', non_numeric_cols)
    print('\n\n Nan before imputing are')
    # convert non-numerical categories to numeric
    for x in non_numeric_cols:
        encoded_series, encoding = preprocessing.encode_series_numeric_labels(df[x])
        print('length of original series is: ' + str(df.shape))
        print('dimensions of returned series is: ', len(encoded_series))
        print('encoded labels are: \n', encoding)
        print('************************************************************************************')
        # check values at indices which are no longer in the series
        missing_idx = [x for x in df.index if x not in encoded_series.index]
        print('\n values that are in original series but not in returned series are:')
        print(df[x][missing_idx].value_counts(dropna=False))
        df[x] = encoded_series
    # returned data frame will be all numeric encoded series along with nan's

    # step-7: impute float with mean and int with mode
    discrete_columns = [x for x in df.columns if df[x].dtype != float]
    continuous_columns = [x for x in df.columns if df[x].dtype == float]
    print('@@@@@@@@@@@@ Nan in columns before imputing \n\n')
    for x in df.columns:
        print('nan in ', x, ' are :\n', pd.isnull(df[x]).sum())
    df = preprocessing.impute(df, 'mean', continuous_columns)
    df = preprocessing.impute(df, 'mode', discrete_columns)
    print('@@@@@@@@@@@@ Nan in columns after imputing \n\n')
    for x in df.columns:
        print('nan in ', x, ' are :\n', pd.isnull(df[x]).sum())
    # step-8: outlier treatment (using box plots)
    eda.export_boxplot(df, cols[0], None, 'All', '', '.png')
    print('\nBefore:', len(df.index))
    df = preprocessing.filter_outliers(df, 'two-sided', 2.5, 'Age', 'percent_points')
    print('\nAfter:', len(df.index))
    # step-9: perform feature engineering
    # step-10: model building (training, testing & validation)
        # 10.1: Performance evaluation
        # 10.2: results visualization
    # step-11: hyper parameter tuning



def test_encode_numeric_labels():
    print('\n\n\n\n\n\n\n\n\n\n\n\n*********************************\n\n')
    df = import_data_csv('../../src/data/train.csv')
    print('data imported')
    df_original = df
    df = df.drop(['Name'], axis=1)
    cols = df.columns
    print('columns in df are:\n', cols)
    numeric_cols = [x for x in cols if df[x].dtype != object]
    print('\nnumeric columns are:\n', numeric_cols)
    non_numeric_cols = [x for x in cols if df[x].dtype == object]
    print('\nNon numeric columns are:\n', non_numeric_cols)
    print('\n\n Nan before imputing are')
    preprocessing.encode_numeric_labels(df, df.columns)


def test_encode_series_order_numeric_labels():
    # step-1 import data set & identify target
    df = import_data_csv('../../src/data/train.csv')
    print('data imported')
    df_original = df.copy()
    cols = df.columns
    print('columns in df are:\n', cols)
    target = df[cols[0]]
    df = df.replace(None, np.NAN)
    df = df.replace('NA', np.NAN)
    # step-2 delete columns which are not significant just by glancing (some examples are names, id's...)
    # remove name
    df = df.drop(['Name'], axis=1)


test_encode_series_numeric_labels()
# test_encode_numeric_labels()
# test_encode_series_order_numeric_labels()