from sklearn.datasets import load_breast_cancer
import pandas as pd
from in_out import import_data_csv
import eda

data = load_breast_cancer()
X = pd.DataFrame(data['data'])
X.columns = data['feature_names']
y = pd.DataFrame(data['target'])
y.columns = ['target']
print(X.columns)
print(y.columns)
print(X.head())
df_to_save = X
df_to_save['target'] = y['target']
df_to_save.to_csv('./data/df.csv')


# Import dataset
# df = import_data_csv('./data/df.csv')
df = import_data_csv('./data/train.csv')
original_data = df
eda.dataset_stats_info(df)


# export histograms
eda.export_histograms(df, extension='.png')
