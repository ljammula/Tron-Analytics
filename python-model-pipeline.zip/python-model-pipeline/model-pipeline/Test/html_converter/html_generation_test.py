import os.path
from html_converter import generate_html_output_with_links

print('Testing generate HTML for EDA images')

# imgs_dir = '/Users/laxminarsimhareddyjammula/PycharmProjects/python-model-pipeline/Test/reports/figures'
# output_dir = '/Users/laxminarsimhareddyjammula/PycharmProjects/python-model-pipeline/Test/reports'
# relative path
imgs_dir = os.path.realpath(os.path.join(os.getcwd(), "../", "reports", "figures/"))
output_dir = os.path.realpath(os.path.join(os.getcwd(), "../", "reports"))
generate_html_output_with_links(imgs_dir, 'EDA', 'EDA_with_links.html', output_dir, 'eda')
