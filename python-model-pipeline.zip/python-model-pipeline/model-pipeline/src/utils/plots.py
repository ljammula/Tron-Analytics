import math
import numpy as np
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt
from utils.misc import mannwhit, fill_vals
from utils.formatting import convert_p, round_sig_figs
from pandas.plotting import table
from constants import project_colors
from matplotlib.font_manager import FontProperties


def plot_boxplot(df, feature, target, sig='auto'):

    """
    Crates a box plot for a specific feature separated by a target variable.
    The wiskers show  the most extreme points within 1.5*IQR of the inter
    quartile range.

    :param df: input data frame (pd.DataFrame)
    :param feature: column label of continuous variable (str)
    :param target: column label of discrete target variable (str)
    :param sig: options for displaying significance. Options listed below (str)
    :return: matplotlib plot
    Options for sig:
    'sig' show all significant pairs
    'ns' show all insignificant pairs
    'none' don't show any significance marks
    'auto' show all significat pairs if there are 4 or less categories
    """
    plt.clf()

    # Check for null values

    if df[feature].isnull().values.any():

        print('\n\n***')

        print('Warning: NaN values present in feature ' + feature + '. '

              'Automatically removing them to create boxplot.')

        print('***\n')

    input_df = df.dropna(subset=[feature])

    num_datapoints = len(input_df)

    # Fill nulls so they will be included

    input_df[target].fillna('Null', inplace=True)

    # Determine categories

    categories = input_df[target].unique()

    num_categories = len(categories)

    # Sort mixed data types

    # TODO mixed numeric types should be sorted together, but aren't (e.g.,

    # floats will come before ints currently).

    type_list = [type(x) for x in categories]

    categories_sorted = []

    for t in set(type_list):

        mask = [x == t for x in type_list]

        categories_sorted.extend(sorted(categories[mask]))

    # Separate data by category

    data = [input_df[feature][input_df[target] == cat] for cat in

            categories_sorted]

    # Find medians to add to labels

    meds = [data[i].median() for i in range(num_categories)]

    # Generate x labels

    labels = [str(categories_sorted[i]) + '\nM: %3.1f' % meds[i] for i in

              range(num_categories)]

    chart = plt.boxplot(data, labels=labels, widths=0.75, showfliers=False)

    plt.setp(chart['medians'], color=project_colors.PURPLE_2)

    plt.setp([chart['whiskers'], chart['boxes'], chart['caps']],

             color=project_colors.GREEN_1)

    # Add axis labels and title

    plt.xlabel('\nCategory (' + target + ', %s samples)' % int(num_datapoints))

    plt.ylabel(feature)

    plt.title(feature + ' Distribution per ' + target)

    # Perform significance tests

    if not(sig is None):

        if not (sig == 'auto' and num_categories > 4):

            # Generate list of pairs

            pairs = [(i, j) for i in range(num_categories) for j in

                     range(num_categories) if j > i]

            # Find p-values

            u = [mannwhit(data[pairs[i][0]], data[pairs[i][1]], feature) for i

                 in range(len(pairs))]

            # Convert p to stars

            u_stars = [convert_p(u[i]) for i in range(len(u))]

            # u_plot = [(pairs[i][0], pairs[i][1], u_stars[i]) for i in range(

            # len(u_stars)) if u_stars[i] != 'ns']

            if sig == 'sig' or sig == 'auto':

                u_plot = [{'plot_1': pairs[i][0], 'plot_2': pairs[i][1],

                           'stars': u_stars[i]} for i in range(len(u_stars))

                          if u_stars[i] != 'ns']

            elif sig == 'ns':

                u_plot = [{'plot_1': pairs[i][0], 'plot_2': pairs[i][1],

                           'stars': u_stars[i]} for i in range(len(u_stars))

                          if u_stars[i] == 'ns']

            else:

                print('Invalid option for sig.')

                return()

            # Find top of each plot so indicators can go above that

            tops = [chart['caps'][(2 * i) - 1]._y[0] for i in

                    range(num_categories)]

            top = max(tops)

            # Add test significance mark

            y_range = abs(plt.ylim()[1] - plt.ylim()[0])

            h = 0.03 * y_range  # Length of tick and height above whisker

            # Heights of significance label as fraction of plot height

            height_boost = 0.25 * y_range

            i = 0

            for x in u_plot:

                # Set columns. Add one since first plot is positioned at x=1

                x1, x2 = x['plot_1'] + 1, x['plot_2'] + 1

                # To set different heights for each pair

                # top = max([tops[x['plot_1']], tops[x['plot_2']]])

                # Create line to connect significant plots.

                # y is start of tick, col is color

                y, col = top + h + height_boost*i, 'k'

                plt.plot([x1, x1, x2, x2], [y, y+h, y+h, y], lw=1.5, c=col)

                plt.text((x1+x2)*.5, y+h, x['stars'], ha='center', va='bottom',

                         color=col)

                i += 1

    # Ensure all text shows

    plt.tight_layout()



def plot_discrete_histogram(s, log_option, feature, categories='auto'):
    # Uses bar chart to make a histogram of the data series s where the possible
    # values are discrete bins.
    # Inputs:
    # - s is a pandas data series of values to be plotted
    # - categories is a list of categories to use. It will be automatically
    # determined from the data if set to 'auto'. Alternatively, a list or
    # pandas Series of categories can be passed if empty categories should be
    # included for consistency with other graphs.

    plt.clf()

    # Find or set the possible values for categories

    if categories == 'auto':
        possible_vals = s.unique()
        try:
            # Mixed data types can't be sorted. E.g., a list of strings with
            # a nan will not sort. Don't sort in this case.
            # as an alternative, removing nan's from the possible values
            possible_vals = sorted([x for x in possible_vals if str(x) != 'nan'])
            # possible_vals = sorted(possible_vals)
        except:
            print('Categories could not be sorted for feature ' + feature)
    else:
        possible_vals = categories

    # Define positions x
    x = [n + 1 for n in range(len(possible_vals))]
    # Define heights of bars
    total = len(s)
    counts = s.value_counts(dropna=False)
    pct = 100 * counts / total
    heights = [fill_vals(pct, key) for key in possible_vals]
    counts = [fill_vals(counts, key) for key in possible_vals]
    # Make plot
    plt.bar(x, heights, tick_label=possible_vals, log=log_option,
            color=project_colors.L_BLUE_2)
    plt.xlabel('Category')
    plt.ylabel('Percent of Occurrences')
    plt.title('Feature: ' + feature)
    # Add bin height labels
    bin_label_xpos = x
    bin_label_text = [str(round(x, 1)) + '%\n' + str(y) for (x, y) in
                      zip(heights, counts)]

    if log_option:

        bin_labels = list(
            zip(bin_label_xpos, [1.1 * h for h in heights], bin_label_text))

        # Set plot limits
        plt.ylim(min(1, plt.ylim()[0]),
                 math.log(0.5 * (plt.ylim()[1] - plt.ylim()[0]) +
                          10**plt.ylim()[1]))

    else:
        bin_labels = list(
            zip(bin_label_xpos, [h + 1 for h in heights], bin_label_text))
        plt.ylim(plt.ylim()[0], plt.ylim()[1] + 5)

    for i in range(len(bin_labels)):
        plt.text(*bin_labels[i], horizontalalignment='center')

    # Change y axis to include percents

    ax = plt.gca()

    vals = ax.get_yticks()

    ax.set_yticklabels(['{:g}%'.format(x) for x in vals])

    # Ensure labels aren't outside of printed area

    plt.tight_layout()



def plot_continuous_histogram(data, log_option, feature, nbins=None,

                              filter=None):

    # Note that bins are left inclusive (i.e., they include the left endpoint).

    # The x-axis tick marks are rounded to two digits

    # Inputs:

    # - filter is a two-length tuple giving minimum and maximum values for

    # filtering. Any values within this range (inclusive of both endpoints)

    # will be kept. Note that bin heights represent fractions of the filtered

    # data, not the overall data. Optional, default None.

    plt.clf()

    data = data.copy()

    # Apply filter

    if type(filter) == tuple:

        data = data[data.between(*filter)]

    if data.isnull().values.any():

        print('NaNs present. Removing.')

        data.dropna(inplace=True)

    # Define weights to normalize bin heights

    weights = np.ones_like(data) / float(len(data))

    # Create histogram

    kwargs = {'bins': nbins, 'align': 'mid', 'log': log_option,

              'weights': weights, 'rwidth': 0.85,

              'color': project_colors.L_BLUE_2}

    n, bins, patches = plt.hist(data, **kwargs)

    # Add bin height labels

    bin_label_xpos = [(bins[i] + bins[i + 1])/2 for i in range(len(bins) - 1)]

    bin_label_text = [str(int(round(x*len(data)))) for x in n]

    if log_option:

        bin_labels = list(zip(bin_label_xpos, 1.1 * n, bin_label_text))

        for i in range(len(bin_labels)):

            # Zeros need to be placed a the lower y limit for log graphs

            if n[i] > 0:

                plt.text(*bin_labels[i], horizontalalignment='center')

            else:

                plt.text(bin_label_xpos[i], 1.1 * plt.ylim()[0], '0',

                         horizontalalignment='center')

    else:

        # Ensure plot starts at zero, likely not necessary to enforce.

        plt.ylim(bottom=0)

        bin_labels = list(zip(bin_label_xpos, n + 0.01, bin_label_text))

        for i in range(len(bin_labels)):

            # Zeros need to be placed a the lower y limit if it's nonzero

            if n[i] > 0:

                plt.text(*bin_labels[i], horizontalalignment='center')

            else:

                plt.text(bin_label_xpos[i], max(0, plt.ylim()[0] + 0.01), '0',

                         horizontalalignment='center')

    # Make sure there's room for the bar labels

    plt.ylim(plt.ylim()[0], plt.ylim()[1] + 0.03)

    # Add plot labels

    plt.xlabel('\nFeature Value')

    plt.ylabel('Fraction of Occurrences')

    plt.title('Feature: ' + feature)

    # X ticks

    plt.xticks(bins, [str(round_sig_figs(x, 2)) for x in list(bins)], rotation='vertical')

    # Ensure labels aren't outside of printed area

    plt.tight_layout()


def draw_table(df, series=False, scale_x=1, scale_y=1, font_size=10, location='upper center', title=''):
    plt.clf()
    fig, ax = plt.subplots(figsize=(12, 2))  # set size frame
    ax.xaxis.set_visible(False)  # hide the x axis
    ax.yaxis.set_visible(False)  # hide the y axis
    ax.set_frame_on(False)  # no visible frame, uncomment if size is ok
    if series:
        tabla = table(ax, df, loc=location, cellLoc='center', rowLoc='center')  # where df is your data frame
        tabla.auto_set_font_size(False)  # Activate set fontsize manually
        tabla.set_fontsize(font_size)  # if ++fontsize is necessary ++colWidths
        tabla.scale(1, 0.8)
    else:
        tabla = table(ax, df, loc=location, colWidths=[0.17] * len(df.columns), cellLoc='center', rowLoc = 'center')  # where df is your data frame
        tabla.auto_set_font_size(False)  # Activate set fontsize manually
        tabla.set_fontsize(font_size)  # if ++fontsize is necessary ++colWidths
        tabla.scale(scale_x, scale_y)  # change size table
    for (row, col), cell in tabla.get_celld().items():
        if (row == 0) or (col == -1):
            cell.set_text_props(fontproperties=FontProperties(weight='bold'))
    plt.title(title)