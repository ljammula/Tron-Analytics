from scipy.stats import mannwhitneyu
import base64


def mannwhit(x1, x2, feature):
    """
    Wraper for Mann Whitney U test that catches the exception for all values the same (or any other value error)
    :param x1: data set one (pd.Series)
    :param x2: data set two (pd.Series)
    :param feature: name of feature being plotted (str)
    :return: p value from two sided test (float)
    """
    try:
        return(mannwhitneyu(x1, x2, alternative='two-sided').pvalue)
    except ValueError:
        print('Value error for feature', feature)
        return 1.0


def fill_vals(data, key):
    """
    Function to fill unoccupied keys with zero. Used to plot discrete histograms with empty bins.
    :param data: pd.Series
    :param key: name of empty key to add
    """
    try:
        return data[key]
    except KeyError:
        return 0


def count_nans(data):
    """
    counts nulls in a data series
    :param data: pd.Series
    :return: number of null entries
    """
    return data.isnull().sum()


def base64_encode(file):
    with open(file, "rb") as f:
        data = f.read()
        encoded = base64.b64encode(data)
        # decode byte to remove b' and ' characters
        decoded = str(encoded, 'utf-8')
    return decoded