# function to create folders for output
import os


# create a new directory in specified path if one doesn't exist
def mkdir(path):
    print('create new directory if necessary')
    if not os.path.isdir(path):
        os.makedirs(path)
        print('Directory ' + path + ' created.')
    else:
        print('Directory ' + path + ' already exists. ')
        

def setup_directories(rel_path, subfolder = None):
    # created new directory at the current working_directory + real_path + subfolder and returns path
    # find current directory
    cwd = os.path.dirname(os.getcwd())
    # add path to desired directory
    if subfolder is None:
        path = os.path.join(cwd, rel_path)
    else:
        path = os.path.join(cwd, rel_path, subfolder, '')
    # make new directory if necessary
    if not os.path.isdir(path):
        print('creating directory:', path)
        mkdir(path)
    return path