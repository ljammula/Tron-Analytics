import math
import pandas as pd


def convert_p(p):
    """
    converts p-value to stars
    :param p: p-value to be converted
    :return: float
    """


def round_sig_figs(x, n=1):
    # function to round x to n significant digits
    if x == 0:
        return 0
    if math.isnan(x):
        return math.nan
    approx = round(x, -int(math.floor(math.log10(abs(x)))) + (n - 1))
    # remove trailing decimals if number is an integer
    if int(approx) == approx:
        approx = int(approx)
    return approx


def round_nearest(x, a):
    # rounds x to nearest multiple of a. This method rounds to precision a, and then to number
    # number of significant digits a has.
    return round(round(x/a)*a, -int(math.floor(math.log10(a))))


def format_dates(s, format='auto'):
    """
    format dates to YYYY-MM-DD string format.
    NUlls and dates that cannot be parsed are returned as 'NaT'
    :param s: pd.series
    :param format: "auto" the format will be YYYY-MM-DD
    custom formatting can be specified , e.g. as "%m/%d/%Y".(str)
    :return: pd.series (with dates formatted as strings)
    """
    s = s.copy()
    kwargs = {}
    if format == 'auto':
        kwargs['infer_datetime_format'] = True
    else:
        kwargs['format'] = format
    return pd.to_datetime(s, errors='coerce', **kwargs).astype(str)