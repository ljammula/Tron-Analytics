import celery
import os
import numpy as np

import python_model_pipeline as pmp


print(celery.__file__)
# Begin celery config
broker_url = 'amqp://guest@localhost'  # Broker URL for RabbitMQ task queue
app1 = celery.Celery('python-model-pipeline-Async')
app1.conf.update(BROKER_URL=broker_url,
                CELERY_RESULT_BACKEND=broker_url)


@app1.task(bind=True)
def some_long_task(self):
    print('in long running task')
    perform_eda()


def perform_eda():
    # step-1 import data set & identify target
    df = pmp.in_out.data_files.import_data_csv('/Users/laxminarsimhareddyjammula/PycharmProjects/python-model-pipeline/src/data/train.csv')
    print('data imported')
    df_original = df.copy()
    cols = df.columns
    print('columns in df are:\n', cols)
    target = df[cols[0]]
    # replace Null, NA with np.NAN
    df = df.replace('NULL', np.NAN)
    df = df.replace('NA', np.NAN)

    # Step-2: Do summary statistics part-1
    # go through the text file
    pmp.eda.describe.dataset_stats_info(df)

    # step-3 delete columns which are not significant just by glancing (some examples are names, id's...)
    # remove name
    df = df.drop(['Name'], axis=1)
    cols = df.columns

    # Step-4: perform EDA
    # i) plot visualizations to understand data better
    pmp.eda.plot.export_histograms(df, extension='.png')
    pmp.eda.plot.export_boxplot(df, cols[0], None, 'All', '', '.png')
    pmp.eda.plot.export_correlation_plot(df, '', '.png')
    # ii) generate a single html with visualizations
    imgs_dir = os.path.realpath(os.path.join(os.getcwd(), "../../", "reports", "figures/"))
    output_dir = os.path.realpath(os.path.join(os.getcwd(), "../../", "reports"))
    pmp.generate_html.generate_html_output_with_links(imgs_dir, 'EDA', 'EDA_with_links.html', output_dir, 'eda')