from flask import Flask, jsonify
from flask import abort
from flask import request
from flask import make_response
import tasks


# Begin celery config
app = Flask(__name__)


@app.route('/')
def index():
    return 'Hello World!'


@app.route('/python-model-pipeline/health', methods=['GET'])
def tron_welcome():
    return 'Welcome to python-model-pipeline!!!'


# usage /python-model-pipeline/v1/generate_eda?uuid=456-qwe-abc-123
@app.route('/python-model-pipeline/v1/generate_eda', methods=['POST'])
def perform_eda():
    uuid = request.args.get('uuid', default=1, type=str)
    if len(uuid) == 0:
        abort(404)
    else:
        print('*********** Received Request *********  ', 'uuid = ', uuid)
        tasks.some_long_task.delay()  # Call your async task and pass whatever necessary variables
    return make_response(jsonify({'status': 'Processing'}), 200)


@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error': 'Not found'}), 404)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5050, debug=True)