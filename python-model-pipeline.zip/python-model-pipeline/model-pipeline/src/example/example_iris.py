from sklearn import datasets
import preprocessing
import pandas as pd
import eda
import numpy as np
import os.path
from html_converter import generate_html_output_with_links_v2
import seaborn as sns
import matplotlib.pyplot as plt
from constants import misc_const
from utils.environment import mkdir, setup_directories
from sklearn.cluster import KMeans

# Declare constants for paths
# these paths needs to be given in individual plotting files
REPORTS = 'reports_iris'
FILES_PATH = '../'+REPORTS+'/'
FIGURES_PATH = os.path.join(FILES_PATH, 'figures/')
EDA_PATH = os.path.join(FIGURES_PATH, 'eda/')
HISTOGRAM_PATH = os.path.join(EDA_PATH, 'histograms/')
BOXPLOT_PATH = os.path.join(EDA_PATH, 'boxplots/')
INDIVIDUAL_BOXPLOT_PATH = os.path.join(BOXPLOT_PATH, 'individual/')
PAIRPLOT_PATH = os.path.join(EDA_PATH, 'pairplot/')
SCATTERPLOT_PATH = os.path.join(EDA_PATH, 'scatter_plot/')
INFO_PATH = os.path.join(FILES_PATH, 'info/')
CORRELATION_HEATMAP_PATH = os.path.join(EDA_PATH, 'correlation_plot/')
HTML_OUTPUT_DIRECTORY_PATH = os.path.join(FILES_PATH, "html_reports"+'/')
html_output_dir=HTML_OUTPUT_DIRECTORY_PATH
MODEL_PATH = 'model/'
LINEAR = 'linear/'
LOG = 'log/'
# End of constants


def fetch_iris_data():
    iris = datasets.load_iris()
    print(iris['DESCR'])
    X_labels = iris['feature_names']
    y_labels = iris['target_names']
    X = pd.DataFrame(iris['data'], columns=X_labels)
    y = pd.Series(iris['target'], name='target')
    df = X
    df['target'] = y
    print('\n **************************************** Loaded Data-set *********************************\n')
    print(df.columns)
    print('df shape is: ', df.shape)
    print('\n\nTarget shape:')
    print(y.shape)
    print(y_labels)
    return df


def perform_eda():
    # step-1 import data set & identify target
    df = fetch_iris_data()
    print('data imported')
    df_original = df.copy()
    cols = df.columns
    target_column = cols[len(cols)-1]
    # save the data to file
    df.to_csv('../data/titanic_data.csv')
    print('columns in df are:\n', cols)
    target = df[target_column]
    # replace Null, NA with np.NAN
    df = df.replace('NULL', np.NAN)
    df = df.replace('NA', np.NAN)

    # Step-2: Do summary statistics part-1
    # go through the text file
    eda.dataset_stats_info_v2(df, output_dir=INFO_PATH, html_output_dir=HTML_OUTPUT_DIRECTORY_PATH)

    # step-3 delete columns which are not significant just by glancing (some examples are names, id's...)

    # Step-4: perform EDA
    # i) plot visualizations to understand data better
    eda.export_histograms(df, output_dir=HISTOGRAM_PATH, extension='.png')
    # eda.export_boxplot(df, target_column, None, 'All', output_dir=BOXPLOT_PATH, subfolder='', extension='.png')
    eda.export_sns_boxplot(df, output_dir=BOXPLOT_PATH, name_of_plot="before_outlier_treatment")
    eda.export_correlation_plot(df, CORRELATION_HEATMAP_PATH, '', '', '.png')
    # ii) generate a single html with visualizations
    imgs_dir = os.path.realpath(os.path.join(os.getcwd(), "../../", REPORTS, "figures/"))
    output_dir = os.path.realpath(os.path.join(os.getcwd(), "../../", REPORTS))
    # generate_html_output_with_links(imgs_dir, 'EDA', 'EDA_with_links.html', output_dir, 'eda')
    generate_html_output_with_links_v2(imgs_dir, 'EDA', 'EDA_with_links.html', output_dir, 'eda')

    # step-5: remove columns which have too much missing data
    df = preprocessing.remove_features_missing_data(df)
    cols = df.columns

    # step-6: perform label encoding
    numeric_cols = [x for x in cols if df[x].dtype != object]
    print('\nnumeric columns are:\n', numeric_cols)
    non_numeric_cols = [x for x in cols if df[x].dtype == object]
    print('\nNon numeric columns are:\n', non_numeric_cols)
    print('\n\n Nan before imputing are')
    # convert non-numerical categories to numeric
    for x in non_numeric_cols:
        encoded_series, encoding = preprocessing.encode_series_numeric_labels(df[x])
        print('length of original series is: ' + str(df.shape))
        print('dimensions of returned series is: ', len(encoded_series))
        print('encoded labels are: \n', encoding)
        print('************************************************************************************')
        # check values at indices which are no longer in the series
        missing_idx = [x for x in df.index if x not in encoded_series.index]
        print('\n values that are in original series but not in returned series are:')
        print(df[x][missing_idx].value_counts(dropna=False))
        df[x] = encoded_series
    # returned data frame will be all numeric encoded series along with nan's

    # step-7: impute float with mean and int with mode
    discrete_columns = [x for x in df.columns if df[x].dtype != float]
    continuous_columns = [x for x in df.columns if df[x].dtype == float]
    print('@@@@@@@@@@@@ Nan in columns before imputing \n\n')
    for x in df.columns:
        print('nan in ', x, ' are :\n', pd.isnull(df[x]).sum())
    df = preprocessing.impute(df, 'mean', continuous_columns)
    df = preprocessing.impute(df, 'mode', discrete_columns)
    print('@@@@@@@@@@@@ Nan in columns after imputing \n\n')
    for x in df.columns:
        print('nan in ', x, ' are :\n', pd.isnull(df[x]).sum())
    # step-8: outlier treatment (using box plots)
    print('\nBefore:', len(df.index))
    # looks like only sepal width has outliers
    outlier_cols = ['sepal width (cm)']
    for i in outlier_cols:
        df = preprocessing.filter_outliers(df, 'two-sided', 2, i, 'percent_points')
    print('\nAfter:', len(df.index))
    # eda.export_boxplot(df, cols[0], None, 'All', output_dir=BOXPLOT_PATH, subfolder='', extension='.png')
    eda.export_sns_boxplot(df, output_dir=BOXPLOT_PATH, name_of_plot="after_outlier_treatment")
    # step-9: perform feature engineering
    # step-10: model building (training, testing & validation)

    # importing the Iris dataset with pandas
    dataset = pd.read_csv('../data/Iris.csv')
    x = dataset.iloc[:, [1, 2, 3, 4]].values
    # find_clusters(df[[cols[0], cols[1], cols[2], cols[3]]])
    find_clusters(x)
    # Applying kmeans to the dataset / Creating the kmeans classifier
    kmeans = KMeans(n_clusters=3, init='k-means++', max_iter=300, n_init=10, random_state=0)
    y_kmeans = kmeans.fit_predict(x)
        # 10.1: Performance evaluation
        # 10.2: results visualization
    plt.scatter(x[y_kmeans == 0, 0], x[y_kmeans == 0, 1], s=100, c='red', label='Iris-setosa')
    plt.scatter(x[y_kmeans == 1, 0], x[y_kmeans == 1, 1], s=100, c='blue', label='Iris-versicolour')
    plt.scatter(x[y_kmeans == 2, 0], x[y_kmeans == 2, 1], s=100, c='green', label='Iris-virginica')
    # Plotting the centroids of the clusters
    plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], s=100, c='yellow', label='Centroids')
    plt.savefig('model_result.png')
    # step-11: hyper parameter tuning


# Finding the optimum number of clusters for k-means classification
def find_clusters(x):
    wcss = []
    for i in range(1, 11):
        kmeans = KMeans(n_clusters=i, init='k-means++', max_iter=300, n_init=10, random_state=0)
        kmeans.fit(x)
        wcss.append(kmeans.inertia_)

    # Plotting the results onto a line graph, allowing us to observe 'The elbow'
    plt.plot(range(1, 11), wcss)
    plt.title('The elbow method')
    plt.xlabel('Number of clusters')
    plt.ylabel('WCSS')  # within cluster sum of squares
    plt.savefig('elbow_curve.png')
    plt.clf()

perform_eda()