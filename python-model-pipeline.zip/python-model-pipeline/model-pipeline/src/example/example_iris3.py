from sklearn import datasets
import preprocessing
import pandas as pd
import eda
import numpy as np
import os.path
from html_converter import generate_html_output_with_links_v2, generate_html_output_with_links_v3
from performance_evaluation.plot import export_elbow_curve, export_silhouette_
import seaborn as sns
import matplotlib.pyplot as plt
from constants import misc_const
from utils.environment import mkdir, setup_directories
from sklearn.cluster import KMeans
import shutil
# Though the following import is not directly being used, it is required
# for 3D projection to work
from mpl_toolkits.mplot3d import Axes3D
from in_out import models

# Declare constants for paths
# these paths needs to be given in individual plotting files
REPORTS = 'reports_iris'
FILES_PATH = '../'+REPORTS+'/'
FIGURES_PATH = os.path.join(FILES_PATH, 'figures/')
EDA_PATH = os.path.join(FIGURES_PATH, 'eda/')
HISTOGRAM_PATH = os.path.join(EDA_PATH, 'histograms/')
BOXPLOT_PATH = os.path.join(EDA_PATH, 'boxplots/')
INDIVIDUAL_BOXPLOT_PATH = os.path.join(BOXPLOT_PATH, 'individual/')
PAIRPLOT_PATH = os.path.join(EDA_PATH, 'pairplot/')
SCATTERPLOT_PATH = os.path.join(EDA_PATH, 'scatter_plot/')
INFO_PATH = os.path.join(FILES_PATH, 'info/')
CORRELATION_HEATMAP_PATH = os.path.join(EDA_PATH, 'correlation_plot/')
HTML_OUTPUT_DIRECTORY_PATH = os.path.join(FILES_PATH, "html_reports"+'/')
html_output_dir = HTML_OUTPUT_DIRECTORY_PATH
MODEL_PATH = os.path.join(FIGURES_PATH, 'models/model_results/')
LINEAR = 'linear/'
LOG = 'log/'
# End of constants


def fetch_iris_data():
    iris = datasets.load_iris()
    print(iris['DESCR'])
    X_labels = iris['feature_names']
    y_labels = iris['target_names']
    X = pd.DataFrame(iris['data'], columns=X_labels)
    y = pd.Series(iris['target'], name='target')
    df = X
    df['target'] = y
    # write data to file
    df.to_csv('../data/data.csv')
    print('\n **************************************** Loaded Data-set *********************************\n')
    print(df.columns)
    print('df shape is: ', df.shape)
    print('\n\nTarget shape:')
    print(y.shape)
    print(y_labels)
    return df


def fetch_iris_data2():
    dataset = pd.read_csv('../data/Iris.csv')


def perform_eda():
    # delete directories
    shutil.rmtree(os.path.realpath('../../'+REPORTS), ignore_errors=True)

    # step-1 import data set & identify target
    df = fetch_iris_data()
    print('data imported')
    df_original = df.copy()
    cols = df.columns
    print('columns in df are:\n', cols)
    # replace Null, NA with np.NAN
    df = df.replace('NULL', np.NAN)
    df = df.replace('NA', np.NAN)

    # Step-2: Do summary statistics part-1
    # go through the text file
    eda.dataset_stats_info_v2(df, output_dir=INFO_PATH, html_output_dir=HTML_OUTPUT_DIRECTORY_PATH)

    # step-3 delete columns which are not significant just by glancing (some examples are names, id's...)

    # Step-4: perform EDA
    # i) plot visualizations to understand data better
    eda.export_histograms(df, output_dir=HISTOGRAM_PATH, extension='.png')
    # eda.export_boxplot(df, target_column, None, 'All', output_dir=BOXPLOT_PATH, subfolder='', extension='.png')
    eda.export_sns_boxplot(df, output_dir=BOXPLOT_PATH, name_of_plot="before_outlier_treatment")
    eda.export_correlation_plot(df, CORRELATION_HEATMAP_PATH, '', '', '.png')
    # ii) generate a single html with visualizations
    imgs_dir = os.path.realpath(os.path.join(os.getcwd(), "../../", REPORTS, "figures/"))
    output_dir = os.path.realpath(os.path.join(os.getcwd(), "../../", REPORTS))
    correlation_plot_dir = os.path.realpath(os.path.join(os.getcwd(), "../../", REPORTS, "figures/eda/correlation_plot"))
    generate_html_output_with_links_v3(correlation_plot_dir, '', 'EDA_with_links.html', output_dir, 'correlation_plot')

    # step-5: remove columns which have too much missing data
    df = preprocessing.remove_features_missing_data(df)
    cols = df.columns

    # step-6: perform label encoding
    numeric_cols = [x for x in cols if df[x].dtype != object]
    print('\nnumeric columns are:\n', numeric_cols)
    non_numeric_cols = [x for x in cols if df[x].dtype == object]
    print('\nNon numeric columns are:\n', non_numeric_cols)
    print('\n\n Nan before imputing are')
    # convert non-numerical categories to numeric
    for x in non_numeric_cols:
        encoded_series, encoding = preprocessing.encode_series_numeric_labels(df[x])
        print('length of original series is: ' + str(df.shape))
        print('dimensions of returned series is: ', len(encoded_series))
        print('encoded labels are: \n', encoding)
        print('************************************************************************************')
        # check values at indices which are no longer in the series
        missing_idx = [x for x in df.index if x not in encoded_series.index]
        print('\n values that are in original series but not in returned series are:')
        print(df[x][missing_idx].value_counts(dropna=False))
        df[x] = encoded_series
    # returned data frame will be all numeric encoded series along with nan's

    # step-7: impute float with mean and int with mode
    discrete_columns = [x for x in df.columns if df[x].dtype != float]
    continuous_columns = [x for x in df.columns if df[x].dtype == float]
    print('@@@@@@@@@@@@ Nan in columns before imputing \n\n')
    for x in df.columns:
        print('nan in ', x, ' are :\n', pd.isnull(df[x]).sum())
    df = preprocessing.impute(df, 'mean', continuous_columns)
    df = preprocessing.impute(df, 'mode', discrete_columns)
    print('@@@@@@@@@@@@ Nan in columns after imputing \n\n')
    for x in df.columns:
        print('nan in ', x, ' are :\n', pd.isnull(df[x]).sum())
    # step-8: outlier treatment (using box plots)
    print('\nBefore:', len(df.index))
    # looks like only sepal width has outliers
    outlier_cols = ['sepal width (cm)']
    for i in outlier_cols:
        df = preprocessing.filter_outliers(df, 'two-sided', 2, i, 'percent_points')
    print('\nAfter:', len(df.index))
    # eda.export_boxplot(df, cols[0], None, 'All', output_dir=BOXPLOT_PATH, subfolder='', extension='.png')
    eda.export_sns_boxplot(df, output_dir=BOXPLOT_PATH, name_of_plot="after_outlier_treatment")
    # step-9: perform feature engineering

    # step-10: model building (training, testing & validation)
    X = df.iloc[:, :-1].values
    y = df['target'].as_matrix()

    # plot the ground truth
    fig = plt.figure(figsize=(4, 3))
    ax = Axes3D(fig, rect=[0, 0, .95, 1], elev=48, azim=134)

    for name, label in [('Setosa', 0),
                        ('Versicolour', 1),
                        ('Virginica', 2)]:
        ax.text3D(X[y == label, 3].mean(),
                  X[y == label, 0].mean(),
                  X[y == label, 2].mean() + 2, name,
                  horizontalalignment='center',
                  bbox=dict(alpha=.2, edgecolor='w', facecolor='w'))
    # Reorder the labels to have colors matching the cluster results
    y = np.choose(y, [1, 2, 0]).astype(np.float)
    ax.scatter(X[:, 3], X[:, 0], X[:, 2], c=y, edgecolor='k')

    ax.w_xaxis.set_ticklabels([])
    ax.w_yaxis.set_ticklabels([])
    ax.w_zaxis.set_ticklabels([])
    ax.set_xlabel('Petal width')
    ax.set_ylabel('Sepal length')
    ax.set_zlabel('Petal length')
    ax.set_title('Ground Truth')
    ax.dist = 12
    export_path = setup_directories(MODEL_PATH)
    plt.savefig(export_path + "Ground_truth.png", bbox_inches='tight')
    plt.clf()
    #
    clf = train_model(X)
    # step-11: hyper parameter tuning
    models.generate_and_save_pmml(clf, df.iloc[:, :-1].columns)


def train_model(df):
    X = df
    # find_clusters(X)
    export_elbow_curve(X, MODEL_PATH)
    export_silhouette_(X, MODEL_PATH)
    # Applying kmeans to the dataset / Creating the kmeans classifier
    kmeans = KMeans(n_clusters=3, init='k-means++', max_iter=300, n_init=10, random_state=0)
    # 10.1: Performance evaluation
    # 10.2: results visualization
    title = 'Optimal Model (3 clusters)'
    fig = plt.figure(figsize=(4, 3))
    ax = Axes3D(fig, rect=[0, 0, .95, 1], elev=48, azim=134)
    clf = kmeans.fit(X)
    labels = kmeans.labels_
    # Reorder the labels to have colors matching the cluster results
    y = np.choose(labels, [2, 1, 0]).astype(np.float)
    ax.scatter(X[:, 3], X[:, 0], X[:, 2],
               c=y, edgecolor='k')

    ax.w_xaxis.set_ticklabels([])
    ax.w_yaxis.set_ticklabels([])
    ax.w_zaxis.set_ticklabels([])
    ax.set_xlabel('Petal width')
    ax.set_ylabel('Sepal length')
    ax.set_zlabel('Petal length')
    ax.set_title(title)
    ax.dist = 12

    export_path = setup_directories(MODEL_PATH)
    plt.savefig(export_path + "model_viz.png", bbox_inches='tight')
    plt.clf()
    output_dir = os.path.realpath(os.path.join(os.getcwd(), "../../", REPORTS))
    generate_html_output_with_links_v2(export_path, 'model_info', 'model_info.html',
                                       output_dir=output_dir, split_at='models/')
    return clf


perform_eda()