# Contains color definitions
# colors are defined as (R,G,B) as fractions. They are ordered from darkest to lightest.

# Darker blue
D_BLUE_1 = tuple(x/255 for x in (18, 105, 175))
D_BLUE_2 = tuple(x/255 for x in (27, 140, 232))
D_BLUE_3 = tuple(x/255 for x in (1, 169, 246))

# Light blue
L_BLUE_1 = tuple(x/255 for x in (0, 188, 214))
L_BLUE_2 = tuple(x/255 for x in (0, 140, 160))
L_BLUE_3 = tuple(x/255 for x in (122, 208, 224))

# Yellow
YELLOW_1 = tuple(x/255 for x in (223, 185, 10))
YELLOW_2 = tuple(x/255 for x in (251, 197, 3))
YELLOW_3 = tuple(x/255 for x in (247, 219, 103))

# Green
GREEN_1 = tuple(x/255 for x in (105, 149, 51))
GREEN_2 = tuple(x/255 for x in (139, 194, 73))
GREEN_3 = tuple(x/255 for x in (186, 218, 145))

# Purple
PURPLE_1 = tuple(x/255 for x in (116, 28, 131))
PURPLE_2 = tuple(x/255 for x in (155, 37, 175))
PURPLE_3 = tuple(x/255 for x in (177, 77, 197))

