# maintains a list of paths used
import os.path

# these paths needs to be given in individual plotting files
FILES_PATH = '../reports/'
# FILES_PATH = "../../Tron-requests/reports/"

FIGURES_PATH = os.path.join(FILES_PATH, 'figures/')

EDA_PATH = os.path.join(FIGURES_PATH, 'eda/')
HISTOGRAM_PATH = os.path.join(EDA_PATH, 'histograms/')
BOXPLOT_PATH = os.path.join(EDA_PATH, 'boxplots/')
INDIVIDUAL_BOXPLOT_PATH = os.path.join(BOXPLOT_PATH, 'individual/')
PAIRPLOT_PATH = os.path.join(EDA_PATH, 'pairplot/')
SCATTERPLOT_PATH = os.path.join(EDA_PATH, 'scatter_plot/')
INFO_PATH = os.path.join(FILES_PATH, 'info/')
CORRELATION_HEATMAP_PATH = os.path.join(EDA_PATH, 'correlation_plot/')

PERFORMANCE_EVALUATION_PATH = os.path.join(FIGURES_PATH, 'models/')
MODEL_PATH = os.path.join(FIGURES_PATH, 'models/')

LINEAR = 'linear/'
LOG = 'log/'