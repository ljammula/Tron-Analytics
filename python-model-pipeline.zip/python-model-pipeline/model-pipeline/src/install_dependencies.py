import pip
from pip._internal import main


def install(package):
    if hasattr(pip, 'main'):
        pip.main(['install', package])
    else:
        main(['install', package])


# Example
if __name__ == '__main__':
    install('seaborn')
    install('imblearn')
    install('sklearn')
    install('flask')
    install('mako')
    install('celery')
    install('sklearn_pandas')
    install('sklearn2pmml')
    install('xgboost')
    install('pillow')


