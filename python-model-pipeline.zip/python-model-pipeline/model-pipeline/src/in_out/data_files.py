# functions to import data
import pandas as pd
from utils.environment import mkdir
from constants import misc_const


def import_data_csv(path = '../data/df.csv'):
    # returns DataFrame
    print(misc_const.LINE_SEP)
    print('Importing dataset from CSV')
    df = pd.read_csv(path, index_col=0)
    print('Import complete. Dimension of data are: ', str(df.shape), '\n')
    return df