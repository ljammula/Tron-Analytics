from datetime import datetime
import joblib
import os
from utils.environment import setup_directories
from sklearn_pandas import DataFrameMapper
from sklearn2pmml import PMMLPipeline
from sklearn2pmml import sklearn2pmml
from constants import pipeline_paths, misc_const


def generate_and_save_pmml(model_output_fit, training_columns, pkl_name="model", output_dir=pipeline_paths.MODEL_PATH, subfolder=None, allo_multiple_models=False):
    """
    :param model_output_fit: trained model which needs to be saved
    :param training_columns: column indexer of the training set (pandas index)
    :param pkl_name: name of the file (str)
    :param subfolder: optional subfolder
    :return: nam of exported pkl file
    """
    print(misc_const.LINE_SEP)
    print("exporting pmml")
    # setup paths
    export_path = setup_directories(output_dir, subfolder=subfolder)
    # pickle
    if allo_multiple_models:
        pkl_name = pkl_name + '_' + datetime.now().strftime('%Y-%m-%d_%H_%M_%S')

    print('file: ', export_path+pkl_name+'.pkl')
    joblib.dump(model_output_fit, export_path+pkl_name+'.pkl')
    model_from_pkl = joblib.load(export_path+pkl_name+'.pkl')
    # Generate pmml
    default_mapper = DataFrameMapper([(i, None) for i in training_columns])
    model_pipeline = PMMLPipeline([("mapper", default_mapper),
                                   ('classifier', model_from_pkl)
                                   ])
    sklearn2pmml(model_pipeline, export_path+pkl_name+'.pmml')
    print('Completed .pmml and model generation')
    print('Model exported to:\n', export_path+pkl_name+'.pmml')
    return pkl_name


def import_model(pkl_name, subfolder=None):
    """
    :param pkl_name: name of the pkl file to import
    :param subfolder: relative path to pkl model
    :return: imported model
    """
    print(misc_const.LINE_SEP)
    print("importing model")
    path = os.path.dirname(os.getcwd())
    if subfolder is None:
        model_from_pkl = joblib.load(os.path.join(path, pkl_name, '.pkl'))
    else:
        model_from_pkl = joblib.load(os.path.join(path, subfolder, pkl_name, '.pkl'))
    return model_from_pkl