from mako.template import Template
from mako.runtime import Context
from io import StringIO
import shutil
import os
from utils.environment import setup_directories
from utils.misc import base64_encode

# Define constants
HTML_TEMPLATE = os.path.join(os.path.dirname(__file__), 'templates', 'template2.html')
DIR_SPLITTER = '/'  # for windows it should be '\\'

# generate html file with links to image sections
# *** NOTE **** THIS WILL CONVERT only images which are present in folder,
# make sure you don't have any orphan images without folders
# Takes a directory as input and outputs images recursively in that directory to a html


def generate_html_output_with_links_v2(imgs_dir, title, output_filename, output_dir='../imgs_dir', split_at='eda', template_name=HTML_TEMPLATE, HTML_PATH = 'html_reports'):
    mytemplate = Template(filename=template_name)
    dict = link_navigation(imgs_dir, split_at)
    buf = StringIO()
    ctx = Context(buf, module_name=title, imgs_dict=dict)
    mytemplate.render_context(ctx)
    export_path = setup_directories(os.path.join(output_dir, HTML_PATH))
    write_data_to_file(buf, os.path.join(export_path, output_filename))
    buf.close()
    print('html output generated to: \n', os.path.join(export_path, output_filename))


def navigate_directories(root_dir='.', split_at='eda'):
    dict = {}
    leaf_dirs = all_leaf_directories(root_dir)
    for leaf_dir in leaf_dirs:
        modified_files = []
        files = get_all_files(leaf_dir)
        if len(files) > 1:
            files = sorted(get_all_files(leaf_dir))
        hyperlink = ''
        names = leaf_dir.split(split_at)
        if len(names) > 0:
            if len(names[1]) > 0:
                names2 = names[1].split(DIR_SPLITTER)
                for j in names2:
                    hyperlink = hyperlink.strip()+'_'+j
                print('name of hyperlink will be ', hyperlink)
        else:
            print('It is not a qualified directory for hyper-linking')

        for file in files:
            # modified_files.append(os.path.join(leaf_dir, file))
            # use a base64 encoded image instead
            encoded = base64_encode(os.path.join(leaf_dir, file))
            str = 'data:image/{0};base64,{1}' \
                .format(os.path.join(leaf_dir, file).rsplit('.', 1)[-1].lower(), encoded)
            modified_files.append(str)

        dict[hyperlink.lstrip('_')] = modified_files
    return dict


def get_all_files(root_dir):
    for root, dirs, files in os.walk(root_dir, topdown=False):
        return files


def link_navigation(root_dir='.', split_at='eda'+DIR_SPLITTER):
    return navigate_directories(root_dir, split_at)


def all_leaf_directories(root_dir):
    leaf_dirs = []
    for root, dirs, files in os.walk(root_dir, topdown=False):
        if not dirs:
            leaf_dirs.append(root)
    print('leaf dirs are: ', leaf_dirs)
    return leaf_dirs


def write_data_to_file(buf, file_name='file.html'):
    with open(file_name, 'w') as fd:
        buf.seek(0)
        shutil.copyfileobj(buf, fd)
        buf.close()
