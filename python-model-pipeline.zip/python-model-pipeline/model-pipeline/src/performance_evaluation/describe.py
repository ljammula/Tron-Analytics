# evaluate performance of a model
from sklearn.metrics import mean_squared_error, explained_variance_score, r2_score, f1_score, recall_score
# evalaure classifiers
from sklearn.metrics import classification_report, accuracy_score, roc_auc_score, \
    confusion_matrix, average_precision_score, precision_score
# Imbalanced learn
from imblearn.metrics import classification_report_imbalanced
from constants import misc_const


def regression_metrics(y_train, y_test, pred_train, pred_test):
    """
    evaluate regression problem metrics
    :param y_train:
    :param y_test:
    :param pred_train:
    :param pred_test:
    :return:
    """
    print(misc_const.LINE_SEP)
    print('Generating metrics ')
    print('Training R2 %g' % r2_score(y_true=y_train, y_pred=pred_train))
    print('Test R2: %g' % r2_score(y_true=y_train, y_pred=pred_train))
    print()
    mse = mean_squared_error(y_true=y_train, y_pred=pred_train)
    print('Training MSE: %g' % mse)
    mse = mean_squared_error(y_true=y_test, y_pred=pred_test)
    print('Test MSE: %g' % mse)
    print()
    evar = explained_variance_score(y_true=y_train, y_pred=pred_train)
    print('Training explained variance score: %g' % evar)
    evar = explained_variance_score(y_true=y_test, y_pred=pred_test)
    print('Training explained variance score: %g' % evar)


def binary_classification_metrics(y_train, y_test, pred_train, pred_test,
                                  pred_score_train=None, pred_score_test=None):
    """
    :param y_train:
    :param y_test:
    :param pred_train:
    :param pred_test:
    :param pred_score_train: these should be % values for output to compute ROC_AUC
    :param pred_score_test: these should be % values for output to compute ROC_AUC
    :return:
    """
    print(misc_const.LINE_SEP)
    print('Generating metrics ')
    tn, fp, fn, tp = confusion_matrix(y_train, pred_train).ravel()
    specificity_train = tn / (fp + tn)
    tn, fp, fn, tp = confusion_matrix(y_test, pred_test).ravel()
    specificity_test = tn / (fp + tn)
    print('Training precision, Recall, f1 (usally score is for the positive class)')
    print(classification_report(y_true=y_train, y_pred=pred_train))
    print('Test precision, Recall, f1 (usally score is for the positive class)')
    print(classification_report(y_true=y_test, y_pred=pred_test))
    print()
    print('Training accuracy score: %g' % accuracy_score(y_true=y_train, y_pred=pred_train))
    print('Test accuracy score: %g' % accuracy_score(y_true=y_test, y_pred=pred_test))
    print('Training specificity score: %g' % specificity_train)
    print('Test specificity score: %g' % specificity_test)
    print()
    if (pred_score_train is not None) or (pred_score_test is not None):
        print('Training ROC AUC: %g' % roc_auc_score(y_true=y_train, y_score=pred_score_train[:, 1]))
        print('Test ROC AUC: %g' % roc_auc_score(y_true=y_test, y_score=pred_score_test[:, 1]))
        print()
        print('Training average precision score %g' %
              average_precision_score(y_true=y_train, y_score=pred_score_train[:, 1]))
        print('Training average precision score %g' %
              average_precision_score(y_true=y_test, y_score=pred_score_test[:, 1]))
    else:
        print('ROC AUC not available')


def multi_class_classification_metrics(y_train, y_test, pred_train, pred_test):
    print(misc_const.LINE_SEP)
    print('Generating metrics ')
    print('Training accuracy score: %g' % accuracy_score(y_true=y_train, y_pred=pred_train))
    print('Test accuracy score: %g' % accuracy_score(y_true=y_test, y_pred=pred_test))
    print()
    print('Training precision score (micro): %g' % precision_score(y_train, pred_train, average='micro'))
    print('Test precision score (micro): %g' % precision_score(y_test, pred_test, average='micro'))
    print()
    print('Training recall score (micro): %g' % recall_score(y_train, pred_train, average='micro'))
    print('Test recall score (micro): %g' % recall_score(y_test, pred_test, average='micro'))
    print()
    print('Training F1 score (micro): %g' % f1_score(y_train, pred_train, average='micro'))
    print('Test F1 score (micro): %g' % f1_score(y_test, pred_test, average='micro'))
    print()
    print('Test set precision, recall, f1')
    print(classification_report_imbalanced(y_test, pred_test))
    print('\n')
