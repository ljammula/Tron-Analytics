# Trains multiple models and evauluates their performance

from constants import project_colors, misc_const
import os
from utils.environment import mkdir, setup_directories
from constants import pipeline_paths
import matplotlib.pyplot as plt
from performance_evaluation import describe as pe
import time
# Regressors
from sklearn.dummy import DummyRegressor
from sklearn.linear_model import LinearRegression, Lasso, Ridge
from sklearn.ensemble import AdaBoostRegressor, ExtraTreesRegressor, GradientBoostingRegressor, RandomForestRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.svm import LinearSVR, SVR
# Classifiers
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import AdaBoostClassifier, ExtraTreesClassifier, GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.svm import LinearSVC, SVC
# Imbalanced learn
from imblearn.combine import SMOTEENN
from imblearn.pipeline import make_pipeline as make_pipeline_imb


def evaluate_regressors(x_train, y_train, x_test, y_test, models='auto'):
    """
    Evaluate multiple regression models to determine performance of the
    basic, non-tuned models. If X is given as a series, be sure to use
    X.values.reshape(-1, 1) to provide multiple samples of a single feature.
    Prints evaluation metrics to the console.
    :param x_train: Training features
    :type x_train: Dataframe or series
    :param y_train: Training targets
    :type y_train: series
    :param x_test: Test features
    :type x_test: Dataframe or series
    :param y_test: Test targets
    :type y_test: series
    :param models: List of models to run. If list is provided, it must contain
                   model objects. Alternatively, 'auto' will run a list of
                   common models and 'fast' will run a subset of the fast-
                   running models.
    :type models: list or 'auto' or 'fast'
    :return: None
    """

    print(misc_const.LINE_SEP)
    print("Testing baseline models.")
    if models == 'auto':
        models = [DummyRegressor(strategy='median'), LinearRegression(),
                  Lasso(), Ridge(), AdaBoostRegressor(), ExtraTreesRegressor(),
                  GradientBoostingRegressor(), RandomForestRegressor(),
                  KNeighborsRegressor(), MLPRegressor(), LinearSVR(), SVR()]
    if models == 'fast':
        models = [DummyRegressor(strategy='median'), LinearRegression(),
                  Lasso(), Ridge(), GradientBoostingRegressor(),
                  RandomForestRegressor(), LinearSVR()]
    for reg in models:
        start = time.time()
        # Print name of classifier
        print('\n~~', str(reg).split('(', 1)[0], '~~')
        # Fit and evaluate the model
        reg.fit(x_train, y_train)
        pred_train = reg.predict(x_train)
        pred_test = reg.predict(x_test)
        pe.regression_metrics(y_train=y_train, y_test=y_test,
                              pred_train=pred_train, pred_test=pred_test)
        end = time.time()
        print("\nExecution time in seconds: %.2f" % (end - start))


def evaluate_binary_classifiers(x_train, y_train, x_test, y_test,
                                models='auto'):
    """
    Evaluate multiple binary classification models to determine performance
    of the basic, non-tuned models. If X is given as a series, be sure to use
    X.values.reshape(-1, 1) to provide multiple samples of a single feature.
    Prints evaluation metrics to the console.
    :param x_train: Training features
    :type x_train: Dataframe or series
    :param y_train: Training targets
    :type y_train: series
    :param x_test: Test features
    :type x_test: Dataframe or series
    :param y_test: Test targets
    :type y_test: series
    :param models: List of models to run. If list is provided, it must contain
                   model objects. Alternatively, 'auto' will run a list of
                   common models and 'fast' will run a subset of the fast-
                   running models.
    :type models: list or 'auto' or 'fast'
    :return: None
    """
    print(misc_const.LINE_SEP)
    print("Testing baseline models.")
    if models == 'auto':
        models = [DummyClassifier(), AdaBoostClassifier(),
                  ExtraTreesClassifier(), GradientBoostingClassifier(),
                  RandomForestClassifier(), LogisticRegression(), GaussianNB(),
                  KNeighborsClassifier(), MLPClassifier(), LinearSVC(), SVC()]
    if models == 'fast':
        models = [DummyClassifier(), AdaBoostClassifier(),
                  ExtraTreesClassifier(), GradientBoostingClassifier(),
                  RandomForestClassifier(), LogisticRegression(), GaussianNB(),
                  LinearSVC()]
    for clf in models:
        start = time.time()
        # Print name of classifier
        print('\n~~', str(clf).split('(', 1)[0], '~~')
        # Fit and evaluate the model
        clf.fit(x_train, y_train)
        pred_train = clf.predict(x_train)
        pred_test = clf.predict(x_test)
        # Some models don't predict probabilities.
        try:
            pred_proba_train = clf.predict_proba(x_train)
            pred_proba_test = clf.predict_proba(x_test)
        except AttributeError:
            pred_proba_train = None
            pred_proba_test = None
        pe.binary_classification_metrics(y_train, y_test, pred_train, pred_test,
                                         pred_score_train=pred_proba_train,
                                         pred_score_test=pred_proba_test)
        end = time.time()
        print("\nExecution time in seconds: %.2f" % (end - start))


def evaluate_multiclass_classifiers(x_train, y_train, x_test, y_test,
                                    models='auto'):
    """
    Evaluate multiple multiclass classification models to determine performance
    of the basic, non-tuned models. If X is given as a series, be sure to use
    X.values.reshape(-1, 1) to provide multiple samples of a single feature.
    Prints evaluation metrics to the console. Automatically applies
    SMOTEENN to balance classes for one-vs-rest classification.
    :param x_train: Training features
    :type x_train: Dataframe or series
    :param y_train: Training targets
    :type y_train: series
    :param x_test: Test features
    :type x_test: Dataframe or series
    :param y_test: Test targets
    :type y_test: series
    :param models: List of models to run. If list is provided, it must contain
                   model objects. Alternatively, 'auto' will run a list of
                   common models and 'fast' will run a subset of the fast-
                   running models.
    :type models: list or 'auto' or 'fast'
    :return: None
    """
    print(misc_const.LINE_SEP)
    print("Testing baseline models.")
    if models == 'auto':
        models = [DummyClassifier(strategy='uniform'), AdaBoostClassifier(),
                  ExtraTreesClassifier(), GradientBoostingClassifier(),
                  RandomForestClassifier(), LogisticRegression(), GaussianNB(),
                  KNeighborsClassifier(), MLPClassifier(), LinearSVC(), SVC()]
    if models == 'fast':
        models = [DummyClassifier(strategy='uniform'), AdaBoostClassifier(),
                  ExtraTreesClassifier(), GradientBoostingClassifier(),
                  RandomForestClassifier(), LogisticRegression(), GaussianNB(),
                  LinearSVC()]
    for clf in models:
        start = time.time()
        # Print name of classifier
        print('\n~~', str(clf).split('(', 1)[0], '~~')
        # Fit and evaluate the model
        pipe = make_pipeline_imb(SMOTEENN(), clf)
        pipe.fit(x_train, y_train)
        pred_train = pipe.predict(x_train)
        pred_test = pipe.predict(x_test)
        # # Some models don't predict probabilities.
        # try:
        #     pred_proba_train = pipe.predict_proba(X_train)
        #     pred_proba_test = pipe.predict_proba(X_test)
        # except AttributeError:
        #     pred_proba_train = None
        #     pred_proba_test = None
        # Evaluate performance metrics
        pe.multiclass_classification_metrics(y_train, y_test, pred_train,
                                             pred_test)
        end = time.time()
        print("Execution time in seconds: %.2f" % (end - start))