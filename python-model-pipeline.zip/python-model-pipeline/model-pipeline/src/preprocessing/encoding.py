import pandas as pd
from sklearn.preprocessing import LabelEncoder
from constants import misc_const


def encode_series_numeric_labels(series):
    # Encodes labels numerically for single feature
    # Input series in a pandas data series
    # returns a series with numeric encoding for each label and the definitions
    # of those labels
    print(misc_const.LINE_SEP)
    print("Encoding numeric labels")
    # Check for null values
    if series.isnull().values.any():
        print('\n\n***')
        print('Warning: NaN values present. Attempting to remove them for'
              'label encoding. Returned series will have different length than '
              'original.')
        print('***\n')
        series = series.dropna()
    # Instantiate the label encoder
    le = LabelEncoder()
    # Encode labels
    encoded_series = pd.Series(le.fit_transform(series), index=series.index)
    # Print label encoding for reference
    encoding=dict(zip(le.transform(le.classes_), le.classes_))
    print('Label encoding:')
    print(encoding)
    return encoded_series, encoding


# need to fix this, issues with null values right now
def encode_numeric_labels(df, cols):
    # Encodes given features in a data frame numerically
    # Input df is a pandas data frame
    # Input cols is list of columns to encode
    # Returns a data frame with numeric encoding for each label and the
    # definitions of those labels
    print(misc_const.LINE_SEP)
    print('Encoding numeric labels.')
    df_encoded = df.copy()
    # Instantiate the label encoder
    le = LabelEncoder()
    # loop over cols
    for c in cols:
        # Encode labels
        # Check for null values
        if df[c].isnull().values.any():
            print('\n\n***')
            print('warning: NaN values present in column' + c + '.These will be encoded')
            print('***\n')
        df_encoded[c] = pd.Series(le.fit_transform((df[c])), index=df[c].index)
        # print label encoding for reference
        print('\n Label encoding for ' + c + ' feature is:')
        print(dict(zip(le.transform(le.classes_), le.classes_)))
    return df_encoded


def encode_series_specific_orders(s, ordered_labels):
    """
    :param s: Series to be encoded
    :param ordered_labels: elements of s in the prefered increasing order (list)
    :return: pd.Series of original data encoded numerically given the provided order
    """
    print(misc_const.LINE_SEP)
    print('Encoding numeric labels.')
    labels = list(range(len(ordered_labels)))
    replacement_dict = dict(zip(ordered_labels, labels))
    print('\nLabel encoding with specified order:')
    print(replacement_dict)
    return s.replace(replacement_dict)