# Collection of functions useful for data preprocessing
import pandas as pd
from constants import misc_const


def remove_feature(data, remove):
    """
    Removes list of features from dataset
    :param data: Pandas DataFrame
    :param remove: List of column names to be removed (list)
    :return: Pandas DataFrame
    """
    print(misc_const.LINE_SEP)
    print("Removing features")
    keep = [x for x in data.columns if x not in remove]
    return data[keep]


def remove_features_missing_data(df, frac = 0.5):
    cols = df.columns
    df_len = len(df)
    for x in cols:
        null_count = pd.isnull(df[x]).sum()
        null_frac = null_count/df_len
        print('\n\nnan fraction in \'', x, '\' is :\n', null_frac)
        if(null_frac >= frac):
            print('**** dropping column ', x)
            df = df.drop([x], axis=1)
            print("Feature", x, 'removed for too much missing data')
    return df


def filter_dates(data, date_col, start, end, format='auto'):
    """
    Filters dataset by date range. Filter is inclusive of both endpoints.
    Nulls and dates that cannot be parsed are removed.
    :param data: Input data (pd.DataFrame)
    :param date_col: Name of column with date variable to filter by (str)
    :param start: Beginning of date range in format "YYYY-MM-DD" (str)
    :param end: End of date range in format "YYYY-MM-DD" (str)
    :param format: Format of start and end dates. If set to "auto" (default) the format will be automatically
    interpretted (typically successfully). Custom formatting can be defined, e.g., as "%m/%d/%y". (str)
    :return: dataset filtered by daterange (pd.DataFrame)
    """
    print(misc_const.LINE_SEP)
    print("Filtering by dates")
    data = data.copy()
    kwargs = {}
    if format == 'auto':
        kwargs['infer_datetime_addition'] = True
    else:
        kwargs['format'] = format
    datetime = pd.to_datetime(data[date_col], errors='coerce', **kwargs)
    data['datetime_filter_addition'] = datetime
    # Remove any null values(NaT)
    num_nulls = datetime.isnull().sum()
    if num_nulls > 0:
        print('Warnings: %s null values presents. Removing these samples from dataset.' % num_nulls)
        data = data.dropna(subset=['datetime_filter_addition'])
    # filter
    data = data[data['datetime_filter_addition'].between(start, end)]
    # Removed added column
    return data.drop('datetime_filter_addition', axis=1)


def filter_dates_series(data, start, end, format='auto'):
    """
    Use this to filter series
    :param data: Series
    :param start: Beginning of date range in format "YYYY-MM-DD" (str)
    :param end: End of date range in format "YYYY-MM-DD" (str)
    :param format: Format of start and end dates. If set to "auto" (default) the format will be automatically
    interpretted (typically successfully). Custom formatting can be defined, e.g., as "%m/%d/%y". (str)
    :return: series filtered by daterange (pd.Series)
    """
    print(misc_const.LINE_SEP)
    print("Filtering by dates")
    data = data.copy()
    kwargs = {}
    if format == 'auto':
        kwargs['infer_datetime_addition'] = True
    else:
        kwargs['format'] = format
    datetime = pd.to_datetime(data, errors='coerce', **kwargs)
    data = pd.DataFrame({'input' : data, 'datetime_filter_addition': datetime})
    # Remove any null values(NaT)
    num_nulls = datetime.isnull().sum()
    if num_nulls > 0:
        print('Warnings: %s null values presents. Removing these samples from dataset.' % num_nulls)
        data = data.dropna(subset=['datetime_filter_addition'])
    # filter
    data = data[data['datetime_filter_addition'].between(start, end)]
    # Removed added column
    return data['input']


def filter_feature_value(data, filter_feature, start, end, keep_nulls=False):
    """
    Filters dataset by range of specified column. Filter is inclusive
    :param data: pd.DataFrame
    :param filter_feature: name of feature(column) to filter (str)
    :param start: Lowest value to keep
    :param end: highest value to keep
    :param keep_nulls: retain Null
    :return: dataset filtered by daterange (pd.DataFrame)
    """
    print(misc_const.LINE_SEP)
    print("Filtering by feature value")
    data = data.copy()
    #  Handle nulls
    if keep_nulls:
        # Seperate nulls
        nulls = data[data[filter_feature].isnull()]
        data = data.dropna(subset=[filter_feature])
        # Filter
        data = data[data[filter_feature].between(start, end)]
        # add nulls back
        return data.append(nulls)
    else:
        # Remove null values
        num_nulls = data[filter_feature].isnull().sum()
        if num_nulls > 0:
            print("Warning: %s null values present. Removing these samples from dataset. " % num_nulls)
            data = data.dropna(subset=[filter_feature])
        # Filter
        return data[data[filter_feature].between(start, end)]


def filter_outliers(data, sides, to_remove, feature=None, method='percent_values'):
    """

    :param data: pd.DataFrame
    :param sides: 'one-sided', 'two-sided'
    :param to_remove: Amount of outliers to be removed. Percent (1-100) (float, int)
    :param feature: Name of column to filter
    :param method: 'percent_points' - Remove x% of the data samples
                   'percent_values' - Remove x% of the value range
                   'number' - remove x number of samples
    :return: DataFrame
    """
    print(misc_const.LINE_SEP)
    print('Filtering outliers for feature ' + feature)
    if type(data) == pd.core.frame.DataFrame:
        s = data.copy()[feature]
    elif type(data) == pd.core.series.Series:
        s = data.copy()
    else:
        print('Input Data type not recognized')
        return
    # Remove nulls so s can be sorted
    s = s.dropna()
    try:
        s = s.sort_values()
    except TypeError:
        print("Input data can't be ordered. Does it contain mixed types?")
        return
    if method == 'percent_points':
        min_ind = 0
        if sides == 'one_sided':
            max_ind = int(len(s) * (100 - to_remove) / 100)
        elif sides == 'two-sided':
            min_ind = int(len(s) * to_remove / 100)
            max_ind = int(len(s) * (100 - to_remove) / 100)
        else:
            print('Invalid option for argument sides')
            return
        s_filtered = s.iloc[min_ind:max_ind]
    elif method == 'percent_values':
        min_val = min(s)
        max_val = max(s)
        data_range = abs(max_val - min_val)
        if sides == "one_sided":
            max_val = min_val + (data_range * (100 - to_remove) / 100)
        elif sides == "two-sided":
            max_val = min_val + (data_range * (100 - to_remove) / 100)
            min_val = min_val + (data_range * to_remove / 100)
        else:
            print('Invalid option for argument sides.')
            return
        s_filtered = s[s.between(min_val, max_val)]
    elif method == 'number':
        if sides == 'one_sided':
            s_filtered = s.iloc[0: len(s) - to_remove]
        elif sides == 'two_sided':
            s_filtered = s.iloc[to_remove: len(s) - to_remove]
        else:
            print('Invalid option for argument sides.')
            return
    else:
        print("Invalid method selected.")
        return
    # filter dataframe using s
    return data.loc[s_filtered.index]




