import numbers
import pandas as pd
from constants import misc_const


def continuous_to_categorical(s, cutoff=0, inclusive='left'):
    # converts as continuous values feature into a binary classification
    # with 0 if value <= cutoff or 1 if the value > cutoff
    # where the default 'left' inclusive is used. Also, works for multiple bins
    # if given as a list
    # remember to include -np.inf and +np.inf when giving multiple bins
    # returns a series with binary values
    """
    :param s: Pandas.Series
    :param cutoff: float
    :param inclusive: 'left' or 'right'
    :return: Series with binary values
    """
    print(misc_const.LINE_SEP)
    print('converting to categorical')
    non_numeric = bool(sum(set([not isinstance(x, numbers.Number) for x in s])))
    if non_numeric:
        print('Error: series contains non-numeric values. Conversion to binary is not possible')
    else:
        if type(cutoff) != list:
            if inclusive == 'right':
                return (s > cutoff).apply(int)
            elif inclusive == 'left':
                return (s >= cutoff).apply(int)
        else:
            if inclusive == 'right':
                return pd.cut(s, bins=cutoff, right=True, include_lowest=False, labels=False)
            elif inclusive == 'left':
                return pd.cut(s, bins=cutoff, right=True, include_lowest=True, labels=False)


def combine_feature_categories(s, old_labels, new_label, method = 'combine'):
    """
    combines 2 or more categories into single new category.
    useful for merging categories with less representation
    :param s:
    :param old_labels:
    :param new_label:
    :param method: 'keep' - keep the provided labels and combine rest, 'combine' combining provided old_labels
    :return:
    """
    print(misc_const.LINE_SEP)
    print('combine categories.')
    if method == 'combine':
        return s.replace(to_replace=old_labels, value=new_label)
    elif method == 'keep':
        to_replace = [i for i in s.unique() if i not in old_labels]
        return s.replace(to_replace=to_replace, value=new_label)
    else:
        print('Invalid method chosen')
        return

