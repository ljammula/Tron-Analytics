import numbers
from constants import misc_const
from imblearn.combine import SMOTEENN
from imblearn.combine import SMOTETomek
import pandas as pd


def impute(df, method, cols='All'):
    #  Impute missing values with mean or median
    """
    :param df: Input DataFrame
    :param method: 'mean' or 'median' or 'mode'
    :param cols:
    :return: DataFrame with Nulls imputed
    """
    print(misc_const.LINE_SEP)
    print("Imputing missing values")
    output = df.copy()
    if cols == 'All':
        cols = output.columns
    for c in cols:
        # Test if column is numeric
        non_numeric = bool(sum(set([not isinstance(x, numbers.Number) for x in df[c]])))
        if non_numeric:
            print('Column', c, 'is not numeric. Data not imputed')
            continue
        # Determine value to fill with
        if method == 'mean':
            fill_val = output[c].mean()
        elif method == 'median':
            fill_val = output[c].median()
        elif method == 'mode':
            fill_val = output[c].mode()
        else:
            print('Invalid method chosen. No changes made.')
            return
        # Fill
        output[c].fillna(fill_val, inplace=True)
    return output


# use imbalance learn for balancing which is way more efficient than using manual balancing
def create_balanced_dataset(X_train, y_train, clf=SMOTETomek()):
    """
    :param X_train: (dataframe) predictors, make sure these are numerical
    :param y_train: (series) target (of imbalanced class)
    :param clf: SMOTEENN(), SMOTETomek()
    :return: return balanced dataframe
    """
    print('Before rebalancing distribution:')
    print(y_train.value_counts())
    X_balanced, y_balanced = clf.fit_resample(X_train, y_train)
    print('After rebalancing distribution:')
    df = pd.DataFrame(X_balanced)
    df['target'] = y_balanced
    print(df['target'].value_counts())
    return df