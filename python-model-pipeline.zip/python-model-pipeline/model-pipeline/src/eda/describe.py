from utils.environment import setup_directories
from utils.formatting import round_sig_figs
from constants import pipeline_paths, misc_const
import matplotlib.pyplot as plt
from utils import plots
import pandas as pd


def dataset_stats_info(df, classification='na', val_count_limit=10, info_max_cols=100, filename='data_info',
                       output_dir=pipeline_paths.INFO_PATH):
    """
    stats of a dataframe
    :param df: input DataFrame
    :param classification: defines a target
    :param val_count_limit: for categorical varible, max value counts for how many categories
    :param info_max_cols: max categories to consider
    :param filename: optional to output data to
    :return: prints info to a file
    :param output_dir: prints output to this directory
    """
    print(misc_const.LINE_SEP)
    print('compiling information about data.')
    # setup paths
    export_path = setup_directories(output_dir)

    #print summary statistics to file
    desc = df.describe().round(2)
    # draw table with summary statistics
    plots.draw_table(desc)
    # save the table as a png file
    plt.savefig(export_path+'df_summary_stats'+'.png', transparent=False)
    plt.close()

    # create output file for text output
    with open(export_path + filename + '.txt', 'w') as f:
        # Feature names
        print('Columns in data set: ', file = f)
        print('\t', list(df.columns), file = f)

        numeric_cols = [x for x in df.columns if df[x].dtype != object]
        print('\n\tNumeric columns:\n\t', numeric_cols, file = f)
        non_numeric_cols = [x for x in df.columns if df[x].dtype == object]
        print('\n\tNon numeric columns:\n\t', non_numeric_cols, file = f)

        # DataFrame info
        print('\n\n Data set info: ', file = f)
        if(len(df.columns) > info_max_cols):
            print(' more than permissible columns = ', str(info_max_cols), '. Increase info_max_cols to see more.', file = f)
        df.info(max_cols=info_max_cols, buf=f)

        # draw table with Null information
        null_info = pd.Series(df.isnull().sum(), name='Null Counts')
        len_df = len(df)
        perct_series = pd.Series([(x/len_df)*100 for x in null_info], index=null_info.index, name='Null %')
        null_c_df = pd.concat([null_info, perct_series], axis=1).round(2)
        plots.draw_table(null_c_df, False, 1, 0.8, 8, 'center')
        # save the table as a png file
        plt.savefig(export_path + 'df_null_info' + '.png', transparent=False)
        plt.close()

        # MIN/MAX of numeric values after removing nans
        print('\n\n Min and Max values for each sortable column: ', file = f)
        print('\t***Note that Dates will likely be sorted as Strings.', file = f)
        for c in df.columns:
            try:
                print('\t', '(Min, Max) value of column ' + c + ' : (' + str(min(df[c].dropna())) + ', ',
                      str(max(df[c].dropna())) + ')', file = f)
            except TypeError:
                print('Column ' + c + 'cannot be sorted due to type error (likely that column is of mixed data types.')

        # Counts in each category
        print('\n\n Number of occurences for each category in categorical features with ' + str(val_count_limit) + ' or less categories: ', file = f)
        for c in df.columns:
            if len(df[c].unique()) <= val_count_limit:
                counts = df[c].value_counts(dropna = False)
                print('\n\t value counts of ' + c + ":", file = f)
                for i in range(len(counts)):
                    print('\t', str(counts.index[i]) + ": " + str(counts.iloc[i]), file = f)
        # counts in each class
        if classification != 'na':
            print('\n counts in each class of target variable (' + classification + '):', file = f)
            counts = df[classification].value_counts(dropna=False)
            for i in range(len(counts)):
                print('\t', str(counts.index[i]) + ":"+ str(counts.iloc[i]), file=f)
        print('Info printed to file ' + export_path + filename + '.txt\n\n')

    with open(export_path + filename + '.html', 'w') as f1:
        st1 = """
        <html> 
                <h1 align='center'> Summary  Statistics </h1>
                <object data="df_summary_stats.png"> 
                            <a href = "df_summary_stats.png"> No Support? </a> 
                </object> 
                
                <h1 align='center'> Null Information </h1>
                <object data="df_null_info.png" align="center"> 
                            <a href = "df_null_info.png"> No Support? </a> 
                </object> 
                
                </br>
                
                <h1 align='center'> Data Set Information </h1>
                <object data="data_info.txt" type="text/plain" width=100% style="height: 100%"> 
                    <a href = "data_info.txt"> No Support? </a> 
                </object> 
                
                
        </html>
        """
        f1.write(st1)
        print('Info printed to file ' + export_path + filename + '.html\n\n')
    return


def check_anomalies(df):
    print(misc_const.LINE_SEP)
    print('checking for anomalies in the data')
    anomalies = ['null', 'NULL', 'Null', 'na', 'n/a', '?', 'nan', 'Nan', 'NAN']
    for c in df.columns:
        bad_entries = list(set(df[c].unique()) & set(anomalies))
        if len(bad_entries) > 0:
            print('\n column', c, 'has the following entries that should be ', 'converted to NaN: ')
            print(bad_entries)
            return bad_entries
        else:
            print(' \n column', c, 'does not have any entries that are recognized as needing conversion to NaN.')