# Collection of functions that are useful for exploratory data analysis
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt


import os

from utils.environment import mkdir, setup_directories

import numpy as np

import seaborn as sns

from utils.plots import plot_boxplot, plot_discrete_histogram, \
    plot_continuous_histogram

from constants import pipeline_paths, misc_const





def export_histograms(df, cols='All', output_dir=pipeline_paths.HISTOGRAM_PATH, discrete_cutoff=10, subfolder='', nbins=None, filter=None, extension='.pdf'):

    # Plots histograms for each feature. Note that discrete plots will have

    # heights of percent whereas continuous charts have fractional heights.

    # Input df is a dataframe with data to be plotted

    # Input cols is a list of columns to plot (optional)

    # Input discrete is a boolean or 'auto' to plot discrete features

    # nbins determines the number of bins. Should be left 'auto' unless plotting

    # individual histograms.

    print(misc_const.LINE_SEP)

    print('Exporting histograms.')

    export_path = setup_directories(output_dir,

                                    subfolder=subfolder)

    mkdir(os.path.join(export_path, pipeline_paths.LINEAR))

    mkdir(os.path.join(export_path, pipeline_paths.LOG))

    if cols == 'All':

        cols = df.columns

    for c in cols:

        print('\nCreating histogram for feature: ' + c)

        # Check for null values

        if df[c].isnull().values.any():

            print('\n\n***')

            print('Notice: NaN values present in feature ' + c + '. '

                  'They will be automatically removed for non-categorical '

                  'histograms.')

            print('***\n')

        # Check if feature is discrete

        discrete = 'auto'

        # TODO discrete should be passed as an optional argument but must

        # add a check if it is a bool or 'auto'

        if discrete == 'auto':

            if len(df[c].unique()) <= discrete_cutoff:

                discrete = True

            else:

                discrete = False

        # Create histogram on linear axes

        if discrete:

            plot_discrete_histogram(df[c], False, c)

        else:

            # Check if column is numeric

            if df[c].dtype == 'object':

                print('Notice: Feature ' + c + ' is not numeric. Consider '

                                               'using label encoding.\n')

                continue

            plot_continuous_histogram(df[c].dropna(), False, c, nbins=nbins,

                                      filter=filter)

        plt.savefig(os.path.join(export_path, pipeline_paths.LINEAR, '') +

                    c + extension, bbox_inches='tight')

        # Create histogram on log axes

        if discrete:

            plot_discrete_histogram(df[c], True, c)

        else:

            # Check if column is numeric

            if df[c].dtype == 'object':

                print('Notice: Feature ' + c + ' is not numeric. Consider '

                                               'using label encoding.\n')

                continue

            plot_continuous_histogram(df[c].dropna(), True, c, nbins=nbins,

                                      filter=filter)
        plt.savefig(os.path.join(export_path, pipeline_paths.LOG, '') +

                    c + extension, bbox_inches='tight')
        plt.close()


def export_histograms_sns(df, cols='All', output_dir=pipeline_paths.HISTOGRAM_PATH, discrete_cutoff=10, subfolder='', nbins=None, filter=None, extension='.pdf'):
    # Plots histograms for each feature. Note that discrete plots will have
    # heights of percent whereas continuous charts have fractional heights.
    # Input df is a dataframe with data to be plotted
    # Input cols is a list of columns to plot (optional)
    # Input discrete is a boolean or 'auto' to plot discrete features
    # nbins determines the number of bins. Should be left 'auto' unless plotting
    # individual histograms.

    print(misc_const.LINE_SEP)
    print('Exporting histograms.')
    export_path = setup_directories(output_dir,
                                    subfolder=subfolder)
    mkdir(os.path.join(export_path, pipeline_paths.LINEAR))
    mkdir(os.path.join(export_path, pipeline_paths.LOG))

    if cols == 'All':
        cols = df.columns
    for c in cols:
        print('\nCreating histogram for feature: ' + c)
        # Check for null values
        if df[c].isnull().values.any():
            print('\n\n***')
            print('Notice: NaN values present in feature ' + c + '. '
                  'They will be automatically removed for non-categorical '
                  'histograms.')
            print('***\n')
        import seaborn as sns
        sns.distplot(df[c])
        plt.savefig(os.path.join(export_path, pipeline_paths.LOG, '') +
                    c + extension, bbox_inches='tight')



def export_correlation_plot(df, output_dir=pipeline_paths.CORRELATION_HEATMAP_PATH, filename='', subfolder='', extension='.pdf'):

    # Plots a heatmap of the correlation matrix

    # Input df is a dataframe

    # Input filename is an optional string to append to the file name

    print(misc_const.LINE_SEP)

    print('Generating correlation matrix.')

    export_path = setup_directories(output_dir,
                                    subfolder=subfolder)

    df_corr = df.corr()

    plt.clf()

    # fig, ax = plt.subplots()

    # sns.heatmap(ax=ax, data=df_corr, square=True, annot=True)

    sns.heatmap(data=df_corr, square=True, annot=True)

    plt.xticks(rotation=90)

    plt.yticks(rotation=0)

    plt.savefig(export_path + 'Correlation_Heatmap' + filename +

                extension, bbox_inches='tight')

    print('Correlation matrix exported to: ' + export_path)
    plt.close()




def export_individual_boxplot(df, cols='All', output_dir=pipeline_paths.INDIVIDUAL_BOXPLOT_PATH, subfolder='', show_min_max=False, extension='.pdf'):

    # Generate and export boxplots for each column in the data. This is the

    # individual version that shows some stats on the distribution of each

    # feature. The wiskers show 1.5*IQR above and below the inter quartile

    # range.

    # Input df is a dataframe of data

    # Input cols is a list of strings naming the columns to plot

    # Input subfolder is a string providing the requested subfolder

    # Input show_min_max is a bool indicating whether to show the min and max

    # values on the graph

    print(misc_const.LINE_SEP)

    print("Exporting individual boxplots.")

    export_path = setup_directories(output_dir,

                                    subfolder=subfolder)

    if cols == 'All':

        cols = df.columns

    for c in cols:

        print('\nCreating boxplot for feature: ' + c)

        # Check for null values

        if df[c].isnull().values.any():

            print('\n\n***')

            print('Warning: NaN values present in feature ' + c + '. '

                  'Automatically removing them to create boxplot.')

            print('***\n')

        # Check if column is numeric

        if df[c].dropna().dtype == 'object':

            print('Feature ' + c + ' is not numeric. Consider using label '

                                   'encoding.\n')

            continue

        # Generate boxplot

        plt.clf()

        fig, ax = plt.subplots()

        # Plotting all fliers on big datasets creates pdfs that have too many

        # points to open well. Plot without fliers but add in the min and max

        # values.

        plt.boxplot(df[c].dropna(), labels=[c], showfliers=False)

        if show_min_max:

            plt.scatter([1, 1], [df[c].min(), df[c].max()])

        info = 'Max:' + str(round(float(

                            df[c].max()), 3)) + \
               '\nUQ: ' + str(round(float(
                              df[c].dropna().quantile(q=0.75)), 3)) + \
               '\nMed: ' + str(round(float(np.median(df[c].dropna())), 3)) + \
               '\nLQ: ' + str(round(float(
                              df[c].dropna().quantile(q=0.25)), 3)) + \
               '\nMin:' + str(round(float(
                              df[c].min()), 3))

        plt.text(0.18, 0.75, info, horizontalalignment='center',

                 verticalalignment='center', transform=ax.transAxes)

        plt.ylabel('Value')

        plt.title('Feature: ' + c)

        plt.savefig(export_path + 'Boxplot_' + c + extension,

                    bbox_inches='tight')

        plt.close()

        print('Boxplot for feature ' + c + ' exported to: ' + export_path +

              '\n')





def export_boxplot(df, target, sig=None, cols='All', output_dir=pipeline_paths.BOXPLOT_PATH, subfolder='', extension='.pdf'):

    # Generate and export boxplots for each column given divided by the target.

    print(misc_const.LINE_SEP)

    print("Exporting boxplots.")

    export_path = setup_directories(output_dir,

                                    subfolder=subfolder)

    if cols == 'All':

        cols = df.columns

    for c in cols:

        print('\nCreating boxplot for feature: ' + c)

        # Check if column is numeric

        if df[c].dropna().dtype == 'object':

            print('Feature ' + c + ' is not numeric. Consider using label '

                                   'encoding.\n')

            continue

        # Generate boxplot

        plot_boxplot(df, feature=c, target=target, sig=sig)

        plt.savefig(export_path + 'Boxplot_' + c + extension,

                    bbox_inches='tight')

        plt.close()

        print('Boxplot for feature ' + c + ' exported to: ' + export_path +

              '\n')


def export_sns_boxplot(data, output_dir, name_of_plot):
    # exports single boxplot with all features in it
    # useful for continuous datasets
    plt.clf()
    a4_dims = (11.7, 8.27)
    fig, ax1 = plt.subplots(figsize=a4_dims)
    ax1.tick_params(labelsize=10)
    ax = sns.boxplot(data=data, orient="h", palette="Set2", ax=ax1).set_title(name_of_plot)
    # output file name
    plot_file_name = name_of_plot + ".jpg"
    export_path = setup_directories(output_dir)
    mkdir(os.path.join(export_path))
    to_save = os.path.join(export_path, plot_file_name)
    # save as jpeg
    plt.savefig(to_save)
    plt.close()


def plot_boxplot_individual_sns(x_label, y_label, data, output_dir=pipeline_paths.BOXPLOT_PATH):
    # Generate and export boxplots for each column given divided by the target.
    # not suitable for continuous datasets
    print(misc_const.LINE_SEP)

    print("Exporting boxplots.")

    export_path = setup_directories(output_dir)
    mkdir(os.path.join(export_path))
    # plot boxplot with seaborn
    bplot = sns.boxplot(y=y_label, x=x_label,
                        data=data,
                        width=0.5,
                        palette="colorblind")

    # add swarmplot
    bplot = sns.swarmplot(y=y_label, x=x_label,
                          data=data,
                          color='black',
                          alpha=0.75)

    # output file name
    plot_file_name = x_label.replace(' ', '_').replace('(', '').replace(')', '')+".jpg"
    to_save = os.path.join(export_path, plot_file_name)
    # save as jpeg
    bplot.figure.savefig(to_save,
                         format='jpeg',
                         dpi=100)



def export_pairplot(data, target, cols='all', max_samples=500, random_state=None, output_dir=pipeline_paths.PAIRPLOT_PATH, subfolder='', filename='',

                    extension='.pdf'):

    """

    Pairplots can get very large and take a long time to load. It is recommended

    to select up to 5 features to include plus the target.

    More than 1,000 sample will tend to look muddled and will also take a long

    time to plot. It also will be impossible to open the output file. Data is

    automatically randomly subsampled to avoid this.

    Samples with any null values are automatically dropped (after columns are

    filtered. Columns with non-numeric values will be dropped, but they are

    included in the count of how many columns there are (automatic dropping of

    non-numeric columns may be buggy, so better not to rely on it if you have

    errors).

    Inputs:

    data - data to plot (pd.DataFrame)

    target - name of target feature column to color by (str)

    cols - list of feature columns to include or 'all'. Do not include target

    (list or str)

    subfolder - subfolder to put output files in. Ignored if empty string (str)

    :param extension:

    """

    print(misc_const.LINE_SEP)

    print("Exporting pairplots")

    data = data.copy()

    # Setup paths

    export_path = setup_directories(output_dir,

                                    subfolder=subfolder)

    if cols == 'all':

        cols = data.columns

    # Check if too many columns are being used

    if type(cols) == list and len(cols) > 5:

        print("You selected more than 5 features (plus target). This plot "

              "will take a long time \nto generate and likely won't be "

              "very useful. If you really want to keep them all, pass \n"

              "a filtered dataframe and set cols='all'. No file generated.\n")

        return()

    # Keep only selected columns

    if type(cols) == list:

        cols.append(target)

        data = data[list(set(cols))]

    # Remove nulls

    data.dropna(inplace=True)

    # Check if too many rows are being used

    if len(data) > max_samples:

        data = data.sample(n=max_samples, random_state=random_state)

    # Generate plot

    plot = sns.pairplot(data, hue=target, aspect=1).fig

    # Export

    if filename == '':

        filename = "Pairplot.pdf"

    else:

        filename = "Pairplot_" + filename + ".pdf"

    plot.savefig(export_path + filename, bbox_inches='tight')

    plt.close()

    print('\nPairplot exported to: ' + export_path + '\n')



def export_scatterplot(data, target, cols='all', max_samples=500, random_state=None, output_dir=pipeline_paths.SCATTERPLOT_PATH, subfolder='', extension='.pdf'):

    """

    Scatter plots are useful for regression. Plots each feature against the

    target variable. Scatter plots can get very large and take a long time

    to load. It is recommended to keep less than 1,000 samples. More samples

    will also tend to look muddled and will also take a long time to plot.

    Data is automatically randomly subsampled to avoid this.

    Null values are automatically handled for each feature. Columns with

    non-numeric values will attempt to be sorted by the best method.

    Inputs:

    data - data to plot (pd.DataFrame)

    target - name of target feature column to color by (str)

    cols - list of feature columns to include or 'all'. Do not include target.

    (list or str)

    subfolder - subfolder to put output files in. Ignored if empty string (str)

    :param extension:

    """

    print(misc_const.LINE_SEP)

    print("Exporting scatterplots")

    # Setup paths

    export_path = setup_directories(output_dir,

                                    subfolder=subfolder)

    if cols == 'all':

        cols = data.columns

    elif type(cols) == list:  # Keep only selected columns

        data = data[list(set(cols + [target]))]

    # Remove nulls

    # data.dropna(inplace=True)

    # Check if too many rows are being used

    if len(data) > max_samples:

        data = data.sample(n=max_samples, random_state=random_state)

    # Generate plot

    for feature in cols:

        plt.clf()

        try:

            plt.plot(data[feature], data[target], linestyle='none', marker='.',

                     markersize=0.25)

            # locs, labels = plt.xticks()

            # plt.xticks(locs, labels, rotation='vertical')

            plt.xticks(rotation='vertical')

            plt.xlabel(feature)

            plt.ylabel(target)

            plt.title('Feature Scatter')

            plt.savefig(export_path + feature + extension,

                        bbox_inches='tight')

        except ValueError:

            print("ValueError. Feature " + feature + " could not be plotted.")

            continue

    plt.close()

    print('\nScatterplots exported to: ' + export_path + '\n')


