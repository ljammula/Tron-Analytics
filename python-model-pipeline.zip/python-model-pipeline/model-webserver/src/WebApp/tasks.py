import celery
import os
# import python_model_pipeline components
from python_model_pipeline.in_out import data_files
from python_model_pipeline.eda import describe_v2
from python_model_pipeline.eda import plot
from python_model_pipeline.html_converter import generate_html_v3
from python_model_pipeline.html_converter import generate_html_v4
import preprocessing
import pandas as pd
import numpy as np
import os.path
from performance_evaluation.plot import export_elbow_curve, export_silhouette_
import matplotlib.pyplot as plt
from utils.environment import mkdir, setup_directories
from sklearn.cluster import KMeans
import shutil
# Though the following import is not directly being used, it is required
# for 3D projection to work
from mpl_toolkits.mplot3d import Axes3D
from in_out import models


print(celery.__file__)
# Begin celery config
broker_url = 'amqp://guest@localhost'  # Broker URL for RabbitMQ task queue
app1 = celery.Celery('python-model-pipeline-Async', backend='rpc://', broker=broker_url)
# app1.conf.update(BROKER_URL=broker_url, CELERY_RESULT_BACKEND=broker_url, CELERY_TASK_ACKS_LATE=False,
#                  CELERY_WORKER_ENABLE_REMOTE_CONTROL=True, BROKER_HEARTBEAT=0,
#                  CELERY_CONTROL_QUEUE_EXPIRES=60, CELERY_BROKER_CONNECTION_TIMEOUT=30,
#                  CELERY_WORKER_PREFETCH_MULTIPLIER=1)


@app1.task(bind=True)
def initiate_eda(self, uuid, path='../../../Tron-requests/', data_folder="input/", filename="data.csv",
                 eda_folder='eda/'):
    print('in long running task')
    do_eda(uuid, path, data_folder, filename, eda_folder)


@app1.task(bind=True)
def initiate_model_training(self, uuid, path='../../../Tron-requests/', data_folder="input/", filename="data.csv",
                            eda_folder='eda/', features='All'):
    print('in model-training task')
    perform_training(uuid, path, data_folder, filename, eda_folder, features)


@app1.task(bind=True)
def initiate_model_training_titanic(self, uuid, path='../../../Tron-requests/', data_folder="input/", filename="data.csv",
                            eda_folder='eda/', features='All'):
    print('in model-training task')
    perform_training_titanic(uuid, path, data_folder, filename, eda_folder, features)


def do_eda(uuid, path='../../../Tron-requests/', data_folder="input/", filename="data.csv", eda_folder='eda/'):
    # *******Note:********
    #  This function is same as eda_func. Since, celery cannot import from other modules,
    #  I am duplicating same code here.
    #  Make sure to update this code whenever you update eda_func vice-versa
    # ******* ********
    # always path is same
    # Tron-requests will have uuid folders
    print('received path as: ', path)
    datafolder = os.path.join(path, uuid, data_folder)
    print('datafolder is: ', os.path.abspath(datafolder))
    UUID_PATH = os.path.abspath(os.path.join(path, uuid))
    # create paths for output folders
    FILES_PATH = os.path.abspath(os.path.join(path, uuid, eda_folder))
    print('FILES_PATH is: ', os.path.abspath(FILES_PATH))
    FIGURES_PATH = os.path.join(FILES_PATH, 'eda-plots/')
    HISTOGRAM_PATH = os.path.join(FIGURES_PATH, 'histograms/')
    BOXPLOT_PATH = os.path.join(FIGURES_PATH, 'boxplots/')
    CORRELATION_HEATMAP_PATH = os.path.join(FIGURES_PATH, 'correlation_plot/')
    INFO_PATH = os.path.join(FILES_PATH, 'eda-info/')
    FLG_PATH = os.path.join(UUID_PATH, 'flags/')
    HTML_FOLDER_NAME = "html_reports"
    HTML_OUTPUT_DIRECTORY_PATH = os.path.join(FILES_PATH, "html_reports"+'/')
    print('INFO_PATH is: ', INFO_PATH)
    MODEL_PATH = os.path.join(FIGURES_PATH, 'models/model_results/')


    # step-1 import data set & identify target
    df = data_files.import_data_csv(datafolder+filename)
    print('data imported')
    df_original = df.copy()
    cols = df.columns
    print('columns in df are:\n', cols)
    target = df[cols[0]]
    # replace Null, NA with np.NAN
    df = df.replace('NULL', np.NAN)
    df = df.replace('NA', np.NAN)

    # Step-2: Do summary statistics part-1
    # go through the text file
    describe_v2.dataset_stats_info_v2(df, output_dir=INFO_PATH, html_output_dir=HTML_OUTPUT_DIRECTORY_PATH)

    # step-3 delete columns which are not significant just by glancing (some examples are names, id's...)
    # remove name
    cols = df.columns

    # Step-4: perform EDA
    # i) plot visualizations to understand data better
    plot.export_histograms(df, output_dir=HISTOGRAM_PATH, extension='.png')
    # plot.export_boxplot(df, cols[0], None, 'All', output_dir=BOXPLOT_PATH, extension='.png')
    plot.export_sns_boxplot(df, output_dir=BOXPLOT_PATH, name_of_plot="before_outlier_treatment")
    plot.export_correlation_plot(df, output_dir=CORRELATION_HEATMAP_PATH, extension='.png')
    # ii) generate a single html with visualizations
    imgs_dir = os.path.realpath(FIGURES_PATH)
    output_dir = os.path.realpath(FILES_PATH)
    generate_html_v3.generate_html_output_with_links_v3(HISTOGRAM_PATH, '', 'histograms.html', output_dir, 'histograms',
                                                        HTML_PATH=HTML_FOLDER_NAME)
    generate_html_v3.generate_html_output_with_links_v3(BOXPLOT_PATH, '', 'boxplots.html', output_dir, 'boxplots',
                                                        HTML_PATH=HTML_FOLDER_NAME)
    generate_html_v3.generate_html_output_with_links_v3(CORRELATION_HEATMAP_PATH, '', 'correlation_heatmap.html', output_dir, 'correlation_plot',
                                                        HTML_PATH=HTML_FOLDER_NAME)
    # Step-5: create a flag file if everything goes smooth
    # setup paths
    export_path = setup_directories(FLG_PATH)
    with open(FLG_PATH + 'eda.flg', 'w') as f1:
        print('EDA flag file created ' + FLG_PATH + 'eda.flg' + ' \n\n')

    # Step-6: Dump features into a text file
    with open(INFO_PATH + 'features.txt', 'w') as f:
        for col in cols:
            # write Feature names
            print(col, file=f)
        print('feature file created ' + INFO_PATH + 'features.txt' + ' \n\n')


def perform_training(uuid, path='../../../Tron-requests/', data_folder="input/", filename="data.csv"
                     , eda_folder='eda/', features='All'):
    # *******Note:********
    #  This function is same as eda_func. Since, celery cannot import from other modules,
    #  I am duplicating same code here.
    #  Make sure to update this code whenever you update eda_func vice-versa
    # ******* ********
    # always path is same
    # Tron-requests will have uuid folders
    print('received path as: ', path)
    datafolder = os.path.join(path, uuid, data_folder)
    print('datafolder is: ', os.path.abspath(datafolder))
    UUID_PATH = os.path.abspath(os.path.join(path, uuid))
    # create paths for output folders
    FILES_PATH = os.path.abspath(os.path.join(path, uuid, eda_folder))
    print('FILES_PATH is: ', os.path.abspath(FILES_PATH))
    FIGURES_PATH = os.path.join(FILES_PATH, 'eda-plots/')
    INFO_PATH = os.path.join(FILES_PATH, 'eda-info/')
    FLG_PATH = os.path.join(UUID_PATH, 'flags/')
    print('INFO_PATH is: ', INFO_PATH)
    MODEL_PATH = os.path.join(UUID_PATH, 'models/')
    MODEL_IMGS_PATH = os.path.join(MODEL_PATH, 'model_images/')
    MODEL_RESULTS_PATH = os.path.join(MODEL_IMGS_PATH, 'recommendation/')
    MODEL_ELBOW_CURVE_PATH = os.path.join(MODEL_IMGS_PATH, 'elbow/')
    MODEL_SILHOUETTE_PATH = os.path.join(MODEL_IMGS_PATH, 'silhouette/')
    print('*********************MODEL_PATH************', MODEL_IMGS_PATH)

    # step-1 import data set & identify target
    df = data_files.import_data_csv(datafolder+filename)
    print('data imported')
    df_original = df.copy()
    cols = df.columns
    print('columns in df are:\n', cols)
    target = df[cols[0]]
    # replace Null, NA with np.NAN
    df = df.replace('NULL', np.NAN)
    df = df.replace('NA', np.NAN)

    # Step-2: Do summary statistics part-1
    # go through the text file

    # step-3 delete columns which are not significant just by glancing (some examples are names, id's...)
    # remove name

    # Step-4: perform EDA

    # step-5: remove columns which have too much missing data
    df = preprocessing.remove_features_missing_data(df)
    cols = df.columns
    # just consider the columns passed as input to model
    if features != 'All':
        cols = features
        df = df[features]

    print('********************* DF columns being considered are: \n', df.columns)
    print('********************* shape of df is', df.shape)

    # step-6: perform label encoding
    numeric_cols = [x for x in cols if df[x].dtype != object]
    print('\nnumeric columns are:\n', numeric_cols)
    non_numeric_cols = [x for x in cols if df[x].dtype == object]
    print('\nNon numeric columns are:\n', non_numeric_cols)
    print('\n\n Nan before imputing are')
    # convert non-numerical categories to numeric
    for x in non_numeric_cols:
        encoded_series, encoding = preprocessing.encode_series_numeric_labels(df[x])
        print('length of original series is: ' + str(df.shape))
        print('dimensions of returned series is: ', len(encoded_series))
        print('encoded labels are: \n', encoding)
        print('************************************************************************************')
        # check values at indices which are no longer in the series
        missing_idx = [x for x in df.index if x not in encoded_series.index]
        print('\n values that are in original series but not in returned series are:')
        print(df[x][missing_idx].value_counts(dropna=False))
        df[x] = encoded_series
    # returned data frame will be all numeric encoded series along with nan's

    # step-7: impute float with mean and int with mode
    discrete_columns = [x for x in df.columns if df[x].dtype != float]
    continuous_columns = [x for x in df.columns if df[x].dtype == float]
    print('@@@@@@@@@@@@ Nan in columns before imputing \n\n')
    for x in df.columns:
        print('nan in ', x, ' are :\n', pd.isnull(df[x]).sum())
    df = preprocessing.impute(df, 'mean', continuous_columns)
    df = preprocessing.impute(df, 'mode', discrete_columns)
    print('@@@@@@@@@@@@ Nan in columns after imputing \n\n')
    for x in df.columns:
        print('nan in ', x, ' are :\n', pd.isnull(df[x]).sum())
    # step-8: outlier treatment (using box plots)
    print('\nBefore:', len(df.index))
    # looks like only sepal width has outliers
    if 'sepal width (cm)' in cols:
        outlier_cols = ['sepal width (cm)']
    else:
        outlier_cols = []
    for i in outlier_cols:
        df = preprocessing.filter_outliers(df, 'two-sided', 2, i, 'percent_points')
    print('\nAfter:', len(df.index))
    # step-9: perform feature engineering

    # step-10: model building (training, testing & validation)
    X = df.iloc[:, :-1].values
    y = df['target'].to_numpy()

    # plot the ground truth
    fig = plt.figure(figsize=(4, 3))
    ax = Axes3D(fig, rect=[0, 0, .95, 1], elev=48, azim=134)

    # Reorder the labels to have colors matching the cluster results
    y = np.choose(y, [0, 1, 2]).astype(np.float)
    ax.scatter(X[:, 0], X[:, 1], X[:, 2], c=y, edgecolor='k')

    ax.w_xaxis.set_ticklabels([])
    ax.w_yaxis.set_ticklabels([])
    ax.w_zaxis.set_ticklabels([])
    ax.set_xlabel('sepal length')
    ax.set_ylabel('sepal width')
    ax.set_zlabel('petal width')
    ax.set_title('Ground Truth')
    ax.dist = 12
    export_path = setup_directories(MODEL_RESULTS_PATH)
    plt.savefig(export_path + "Ground_truth.png", bbox_inches='tight')
    plt.clf()
    # start model training
    clf = train_model(X, MODEL_ELBOW_CURVE_PATH, MODEL_SILHOUETTE_PATH, MODEL_RESULTS_PATH)
    # step-11: hyper parameter tuning
    generate_html_v3.generate_html_output_with_links_v3(MODEL_RESULTS_PATH, 'recommendation', 'recommendation.html',
                                       output_dir=MODEL_PATH, split_at='recommendation')
    generate_html_v3.generate_html_output_with_links_v3(MODEL_ELBOW_CURVE_PATH, 'elbow', 'elbow.html',
                                       output_dir=MODEL_PATH, split_at='elbow')
    generate_html_v3.generate_html_output_with_links_v3(MODEL_SILHOUETTE_PATH, 'silhouette', 'silhouette.html',
                                       output_dir=MODEL_PATH, split_at='silhouette')
    # step-12: save model
    models.generate_and_save_pmml(clf, df.iloc[:, :-1].columns, output_dir=MODEL_PATH, pkl_name=uuid)

    # Step-12: create a flag file if everything goes smooth
    # setup paths
    export_path = setup_directories(FLG_PATH)
    with open(FLG_PATH + 'model.flg', 'w') as f1:
        print('EDA flag file created ' + FLG_PATH + 'model.flg' + ' \n\n')

    # Step-6: Dump features into a text file
    with open(MODEL_PATH + 'features.txt', 'w') as f:
        for col in df.iloc[:, :-1].columns:
            # write Feature names
            print(col, file=f)
        print('feature file created ' + INFO_PATH + 'features.txt' + ' \n\n')


def perform_training_titanic(uuid, path='../../../Tron-requests/', data_folder="input/", filename="data.csv"
                     , eda_folder='eda/', features='All'):
    # *******Note:********
    #  This function is same as eda_func. Since, celery cannot import from other modules,
    #  I am duplicating same code here.
    #  Make sure to update this code whenever you update eda_func vice-versa
    # ******* ********
    # always path is same
    # Tron-requests will have uuid folders
    print('received path as: ', path)
    datafolder = os.path.join(path, uuid, data_folder)
    print('datafolder is: ', os.path.abspath(datafolder))
    UUID_PATH = os.path.abspath(os.path.join(path, uuid))
    # create paths for output folders
    FILES_PATH = os.path.abspath(os.path.join(path, uuid, eda_folder))
    print('FILES_PATH is: ', os.path.abspath(FILES_PATH))
    FIGURES_PATH = os.path.join(FILES_PATH, 'eda-plots/')
    INFO_PATH = os.path.join(FILES_PATH, 'eda-info/')
    FLG_PATH = os.path.join(UUID_PATH, 'flags/')
    print('INFO_PATH is: ', INFO_PATH)
    MODEL_PATH = os.path.join(UUID_PATH, 'models/')
    MODEL_IMGS_PATH = os.path.join(MODEL_PATH, 'model_images/')
    MODEL_HTML_PATH = os.path.join(MODEL_PATH, "html_reports"+'/')
    print('*********************MODEL_PATH************', MODEL_IMGS_PATH)

    # step-1 import data set & identify target
    df = data_files.import_data_csv(datafolder+filename)
    print('data imported')
    df_original = df.copy()
    cols = df.columns
    print('columns in df are:\n', cols)
    target = df[cols[0]]
    # replace Null, NA with np.NAN
    df = df.replace('NULL', np.NAN)
    df = df.replace('NA', np.NAN)

    # Step-2: Do summary statistics part-1
    # go through the text file

    # step-3 delete columns which are not significant just by glancing (some examples are names, id's...)
    # remove name

    # Step-4: perform EDA

    # step-5: remove columns which have too much missing data
    df = preprocessing.remove_features_missing_data(df)
    cols = df.columns
    # just consider the columns passed as input to model
    if features != 'All':
        cols = features
        df = df[features]

    print('********************* DF columns being considered are: \n', df.columns)
    print('********************* shape of df is', df.shape)

    # step-6: perform label encoding
    numeric_cols = [x for x in cols if df[x].dtype != object]
    print('\nnumeric columns are:\n', numeric_cols)
    non_numeric_cols = [x for x in cols if df[x].dtype == object]
    print('\nNon numeric columns are:\n', non_numeric_cols)
    print('\n\n Nan before imputing are')
    # convert non-numerical categories to numeric
    for x in non_numeric_cols:
        encoded_series, encoding = preprocessing.encode_series_numeric_labels(df[x])
        print('length of original series is: ' + str(df.shape))
        print('dimensions of returned series is: ', len(encoded_series))
        print('encoded labels are: \n', encoding)
        print('************************************************************************************')
        # check values at indices which are no longer in the series
        missing_idx = [x for x in df.index if x not in encoded_series.index]
        print('\n values that are in original series but not in returned series are:')
        print(df[x][missing_idx].value_counts(dropna=False))
        df[x] = encoded_series
    # returned data frame will be all numeric encoded series along with nan's

    # step-7: impute float with mean and int with mode
    discrete_columns = [x for x in df.columns if df[x].dtype != float]
    continuous_columns = [x for x in df.columns if df[x].dtype == float]
    print('@@@@@@@@@@@@ Nan in columns before imputing \n\n')
    for x in df.columns:
        print('nan in ', x, ' are :\n', pd.isnull(df[x]).sum())
    df = preprocessing.impute(df, 'mean', continuous_columns)
    df = preprocessing.impute(df, 'mode', discrete_columns)
    print('@@@@@@@@@@@@ Nan in columns after imputing \n\n')
    for x in df.columns:
        print('nan in ', x, ' are :\n', pd.isnull(df[x]).sum())
    # step-8: outlier treatment (using box plots)
    print('\nBefore:', len(df.index))
    # looks like only sepal width has outliers
    outlier_cols = ['sepal width (cm)']
    for i in outlier_cols:
        df = preprocessing.filter_outliers(df, 'two-sided', 2, i, 'percent_points')
    print('\nAfter:', len(df.index))
    # step-9: perform feature engineering

    # step-10: model building (training, testing & validation)
    X = df.iloc[:, :-1].values
    y = df['target'].as_matrix()

    # plot the ground truth
    fig = plt.figure(figsize=(4, 3))
    ax = Axes3D(fig, rect=[0, 0, .95, 1], elev=48, azim=134)

    # Reorder the labels to have colors matching the cluster results
    y = np.choose(y, [0, 1, 2]).astype(np.float)
    ax.scatter(X[:, 0], X[:, 1], X[:, 2], c=y, edgecolor='k')

    ax.w_xaxis.set_ticklabels([])
    ax.w_yaxis.set_ticklabels([])
    ax.w_zaxis.set_ticklabels([])
    ax.set_xlabel('sepal length')
    ax.set_ylabel('sepal width')
    ax.set_zlabel('petal width')
    ax.set_title('Ground Truth')
    ax.dist = 12
    ax.legend()
    export_path = setup_directories(MODEL_IMGS_PATH)
    plt.savefig(export_path + "Ground_truth.png", bbox_inches='tight')
    plt.clf()
    # start model training
    clf = train_model(X, MODEL_PATH, MODEL_IMGS_PATH, FILES_PATH)
    # step-11: hyper parameter tuning
    models.generate_and_save_pmml(clf, df.iloc[:, :-1].columns, output_dir=MODEL_PATH)


    # Step-12: create a flag file if everything goes smooth
    # setup paths
    export_path = setup_directories(FLG_PATH)
    with open(FLG_PATH + 'model.flg', 'w') as f1:
        print('EDA flag file created ' + FLG_PATH + 'model.flg' + ' \n\n')

    # Step-6: Dump features into a text file
    with open(MODEL_PATH + 'features.txt', 'w') as f:
        for col in df.iloc[:, :-1].columns:
            # write Feature names
            print(col, file=f)
        print('feature file created ' + INFO_PATH + 'features.txt' + ' \n\n')



def train_model(df, MODEL_ELBOW_CURVE_PATH, MODEL_SILHOUETTE_PATH, MODEL_RESULTS_PATH):
    X = df
    # find_clusters(X)
    export_elbow_curve(X, MODEL_ELBOW_CURVE_PATH)
    export_silhouette_(X, MODEL_SILHOUETTE_PATH)
    # Applying kmeans to the dataset / Creating the kmeans classifier
    kmeans = KMeans(n_clusters=3, init='k-means++', max_iter=300, n_init=10, random_state=0)
    # 10.1: Performance evaluation
    # 10.2: results visualization
    title = 'Optimal Model (3 clusters)'
    fig = plt.figure(figsize=(4, 3))
    ax = Axes3D(fig, rect=[0, 0, .95, 1], elev=48, azim=134)
    clf = kmeans.fit(X)
    labels = kmeans.labels_
    # Reorder the labels to have colors matching the cluster results
    y = np.choose(labels, [1, 0, 2]).astype(np.float)
    ax.scatter(X[:, 0], X[:, 1], X[:, 2],
               c=y, edgecolor='k')

    ax.w_xaxis.set_ticklabels([])
    ax.w_yaxis.set_ticklabels([])
    ax.w_zaxis.set_ticklabels([])
    ax.set_xlabel('sepal length')
    ax.set_ylabel('sepal width')
    ax.set_zlabel('petal width')
    ax.set_title(title)
    ax.dist = 12

    export_path = setup_directories(MODEL_RESULTS_PATH)
    plt.savefig(export_path + "model_viz.png", bbox_inches='tight')
    plt.clf()
    return clf


def setup_directories(rel_path, subfolder = None):
    # created new directory at the current working_directory + real_path + subfolder and returns path
    # find current directory
    cwd = os.path.dirname(os.getcwd())
    # add path to desired directory
    if subfolder is None:
        path = os.path.join(cwd, rel_path)
    else:
        path = os.path.join(cwd, rel_path, subfolder, '')
    # make new directory if necessary
    if not os.path.isdir(path):
        print('creating directory:', path)
        mkdir(path)
    return path


# create a new directory in specified path if one doesn't exist
def mkdir(path):
    print('create new directory if necessary')
    if not os.path.isdir(path):
        os.makedirs(path)
        print('Directory ' + path + ' created.')
    else:
        print('Directory ' + path + ' already exists. ')

