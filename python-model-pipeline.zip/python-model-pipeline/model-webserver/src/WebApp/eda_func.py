import os
import numpy as np
# import python_model_pipeline components
from python_model_pipeline.in_out import data_files
from python_model_pipeline.eda import describe
from python_model_pipeline.eda import plot
from python_model_pipeline.html_converter import generate_html_v2


def do_eda(uuid, path='../../../Tron-requests/', data_folder="input/", filename="data.csv", eda_folder='eda/'):
    # always path is same
    # Tron-requests will have uuid folders
    print('received path as: ', path)
    datafolder = os.path.join(path, uuid, data_folder)
    print('datafolder is: ', os.path.abspath(datafolder))
    # create paths for output folders
    FILES_PATH = os.path.abspath(os.path.join(path, uuid, eda_folder))
    print('FILES_PATH is: ', os.path.abspath(FILES_PATH))
    FIGURES_PATH = os.path.join(FILES_PATH, 'eda-plots/')
    HISTOGRAM_PATH = os.path.join(FIGURES_PATH, 'histograms/')
    BOXPLOT_PATH = os.path.join(FIGURES_PATH, 'boxplots/')
    CORRELATION_HEATMAP_PATH = os.path.join(FIGURES_PATH, 'correlation_plot/')
    INFO_PATH = os.path.join(FILES_PATH, 'eda-info/')
    print('INFO_PATH is: ', INFO_PATH)


    # step-1 import data set & identify target
    df = data_files.import_data_csv(datafolder+filename)
    print('data imported')
    df_original = df.copy()
    cols = df.columns
    print('columns in df are:\n', cols)
    target = df[cols[0]]
    # replace Null, NA with np.NAN
    df = df.replace('NULL', np.NAN)
    df = df.replace('NA', np.NAN)

    # Step-2: Do summary statistics part-1
    # go through the text file
    describe.dataset_stats_info(df, output_dir=INFO_PATH)

    # step-3 delete columns which are not significant just by glancing (some examples are names, id's...)
    # remove name
    df = df.drop(['Name'], axis=1)
    cols = df.columns

    # Step-4: perform EDA
    # i) plot visualizations to understand data better
    plot.export_histograms(df, output_dir=HISTOGRAM_PATH, extension='.png')
    plot.export_boxplot(df, cols[0], None, 'All', output_dir=BOXPLOT_PATH, extension='.png')
    plot.export_correlation_plot(df, output_dir=CORRELATION_HEATMAP_PATH, extension='.png')
    # ii) generate a single html with visualizations
    imgs_dir = os.path.realpath(FIGURES_PATH)
    output_dir = os.path.realpath(FILES_PATH)
    generate_html_v2.generate_html_output_with_links_v2(imgs_dir, 'EDA', 'EDA_with_links.html', output_dir, 'eda-plots')
