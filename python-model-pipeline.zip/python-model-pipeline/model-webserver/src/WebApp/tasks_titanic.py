import celery
import os
import numpy as np
# import python_model_pipeline components
from python_model_pipeline.in_out import data_files
from python_model_pipeline.eda import describe_v2
from python_model_pipeline.eda import plot
from python_model_pipeline.html_converter import generate_html_v2


print(celery.__file__)
# Begin celery config
broker_url = 'amqp://guest@localhost'  # Broker URL for RabbitMQ task queue
app1 = celery.Celery('python-model-pipeline-Async')
app1.conf.update(BROKER_URL=broker_url, CELERY_RESULT_BACKEND=broker_url)


@app1.task(bind=True)
def some_long_task(self, uuid, path='../../../Tron-requests/', data_folder="input/", filename="data.csv",
                   eda_folder='eda/'):
    print('in long running task')
    do_eda(uuid, path, data_folder, filename, eda_folder)


def do_eda(uuid, path='../../../Tron-requests/', data_folder="input/", filename="data.csv", eda_folder='eda/'):
    # *******Note:********
    #  This function is same as eda_func. Since, celery cannot import from other modules,
    #  I am duplicating same code here.
    #  Make sure to update this code whenever you update eda_func vice-versa
    # ******* ********
    # always path is same
    # Tron-requests will have uuid folders
    print('received path as: ', path)
    datafolder = os.path.join(path, uuid, data_folder)
    print('datafolder is: ', os.path.abspath(datafolder))
    UUID_PATH = os.path.abspath(os.path.join(path, uuid))
    # create paths for output folders
    FILES_PATH = os.path.abspath(os.path.join(path, uuid, eda_folder))
    print('FILES_PATH is: ', os.path.abspath(FILES_PATH))
    FIGURES_PATH = os.path.join(FILES_PATH, 'eda-plots/')
    HISTOGRAM_PATH = os.path.join(FIGURES_PATH, 'histograms/')
    BOXPLOT_PATH = os.path.join(FIGURES_PATH, 'boxplots/')
    CORRELATION_HEATMAP_PATH = os.path.join(FIGURES_PATH, 'correlation_plot/')
    INFO_PATH = os.path.join(FILES_PATH, 'eda-info/')
    FLG_PATH = os.path.join(UUID_PATH, 'flags/')
    HTML_FOLDER_NAME = "html_reports"
    HTML_OUTPUT_DIRECTORY_PATH = os.path.join(FILES_PATH, "html_reports"+'/')
    print('INFO_PATH is: ', INFO_PATH)


    # step-1 import data set & identify target
    df = data_files.import_data_csv(datafolder+filename)
    print('data imported')
    df_original = df.copy()
    cols = df.columns
    print('columns in df are:\n', cols)
    target = df[cols[0]]
    # replace Null, NA with np.NAN
    df = df.replace('NULL', np.NAN)
    df = df.replace('NA', np.NAN)

    # Step-2: Do summary statistics part-1
    # go through the text file
    describe_v2.dataset_stats_info_v2(df, output_dir=INFO_PATH, html_output_dir=HTML_OUTPUT_DIRECTORY_PATH)

    # step-3 delete columns which are not significant just by glancing (some examples are names, id's...)
    # remove name
    df = df.drop(['Name'], axis=1)
    cols = df.columns

    # Step-4: perform EDA
    # i) plot visualizations to understand data better
    plot.export_histograms(df, output_dir=HISTOGRAM_PATH, extension='.png')
    plot.export_boxplot(df, cols[0], None, 'All', output_dir=BOXPLOT_PATH, extension='.png')
    plot.export_correlation_plot(df, output_dir=CORRELATION_HEATMAP_PATH, extension='.png')
    # ii) generate a single html with visualizations
    imgs_dir = os.path.realpath(FIGURES_PATH)
    output_dir = os.path.realpath(FILES_PATH)
    generate_html_v2.generate_html_output_with_links_v2(imgs_dir, 'EDA', 'EDA_with_links.html', output_dir, 'eda-plots', HTML_PATH=HTML_FOLDER_NAME)

    # Step-5: create a flag file if everything goes smooth
    # setup paths
    export_path = setup_directories(FLG_PATH)
    with open(FLG_PATH + 'eda.flg', 'w') as f1:
        print('EDA flag file created ' + FLG_PATH + 'eda.flg' + ' \n\n')

    # Step-6: Dump features into a text file
    with open(INFO_PATH + 'features.txt', 'w') as f:
        for col in cols:
            # write Feature names
            print(col, file=f)
        print('feature file created ' + INFO_PATH + 'features.txt' + ' \n\n')


def setup_directories(rel_path, subfolder = None):
    # created new directory at the current working_directory + real_path + subfolder and returns path
    # find current directory
    cwd = os.path.dirname(os.getcwd())
    # add path to desired directory
    if subfolder is None:
        path = os.path.join(cwd, rel_path)
    else:
        path = os.path.join(cwd, rel_path, subfolder, '')
    # make new directory if necessary
    if not os.path.isdir(path):
        print('creating directory:', path)
        mkdir(path)
    return path


# create a new directory in specified path if one doesn't exist
def mkdir(path):
    print('create new directory if necessary')
    if not os.path.isdir(path):
        os.makedirs(path)
        print('Directory ' + path + ' created.')
    else:
        print('Directory ' + path + ' already exists. ')

